public static double[][] transform(double xRot = 0, double yRot = 0, double zRot = 0){
	//Assumes only one of these values is >0 to correct for ordering
	//of rotations;
	double [][] tArray;
	tArray = new double[3][3]
	if (Math.abs(xRot) > 0){	//rotated about x-axis
		tArray ={	{ 1, 0, 0 },
					{ 0, Math.cos(xRot), -Math.sin(xRot) },
					{ 0, Math.sin(xRot), Math.cos(xRot) }
				};
	}
	
	else if (Math.abs(yRot) > 0){
		tArray ={	{ Math.cos(yRot), 0, Math.sin(yRot) },
					{ 0, 1, 0 },
					{ -Math.sin(yRot), 0, Math.cos(yRot) }
				};
	}
	
	else if(Math.abs(zRot) > 0){
		tArray ={	{ Math.cos(zRot), -Math.sin(zRot), 0 },
					{ Math.sin(zRot), Math.cos(zRot), 0 },
					{ 0, 0, 1}
				};
	}
	
	return tArray;
}
