import java.awt.*;
import java.util.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;
import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class singlePanel extends JPanel {
	private JToggleButton button0, button1, button2, button3, button7, button8, button9, button10, button11, button12;
	private	JLabel label0, label1;
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	private static final int XORIGIN = 300;
	private static final int YORIGIN = 380;
	private static final double ARM1_L = 100.;
	private static final double ARM2_L = 100.;
	private static final double ARM3_L = 100.;
	
	
	// Link Length of arm 0 (AND ALL ARMS) 
	private static final int A0 = 100;
	
	private double 	theta0 = -90.0,
					theta1 = 0.0,
					theta2 = 0.0,
					alpha = theta0 + theta1 + theta2;
					
	private int 	xEnd_a0 = XORIGIN,
					yEnd_a0 = YORIGIN,
					xEnd_a1	= XORIGIN,
					yEnd_a1	= YORIGIN,
					xEnd_a2	= XORIGIN,
					yEnd_a2 = YORIGIN;
					
	private Point endPoint;

	private int xpoints_panel0[] = {600, 770, 770, 600};
	private int ypoints_panel0[] = {10, 10, 210, 210};
	private int num_points_panel0 = 4;
	
	
	private int xpoints_panel1[] = {600, 770, 770, 600};
	private int ypoints_panel1[] = {290, 290, 470, 470};
	private int num_points_panel1 = 4;		
	
	private boolean	painting = false;
	private ArrayList points;
	private int rad = 10, i;
	
	private boolean init = true;
	
	public void paint_controller(){
		if(painting){
			painting = false;
		}
		else{
			painting = true;
		}
	}
	
	public Color paint_switch(int x) {
		switch(x)
		{
			case 1: return Color.BLUE;
			case 2: return Color.CYAN;
			case 3: return Color.ORANGE;
			case 4: return Color.GREEN;
			case 5: return Color.YELLOW;
			default: return Color.RED;
		}
	}
					
	public void updateEnds(){
		//input arm lengths and angles, output link points
		xEnd_a0 = (int)(ARM1_L * Math.cos(RADIAN_CONV*theta0))+XORIGIN;
		yEnd_a0 = (int)(ARM1_L * Math.sin(RADIAN_CONV*theta0))+YORIGIN;
		
		xEnd_a1 = (int)(ARM2_L * Math.cos(RADIAN_CONV*(theta0 + theta1)))+xEnd_a0;
		yEnd_a1 = (int)(ARM2_L * Math.sin(RADIAN_CONV*(theta0 + theta1)))+yEnd_a0;
		
		xEnd_a2 = (int)(ARM3_L * Math.cos(RADIAN_CONV*(theta0 + theta1 + theta2)))+xEnd_a1;
		yEnd_a2 = (int)(ARM3_L * Math.sin(RADIAN_CONV*(theta0 + theta1 + theta2)))+yEnd_a1;
		
		
		//System.out.println(xEnd_a0);
		
	}
	
	public void updateEndPoints() {
		xEnd_a0 = -(int)(ARM1_L * Math.cos(RADIAN_CONV*theta0))+XORIGIN;
		yEnd_a0 = (int)(ARM1_L * Math.sin(RADIAN_CONV*theta0))+YORIGIN;
		
		xEnd_a1 = -(int)(ARM2_L * Math.cos(RADIAN_CONV*(theta0 + theta1)))+xEnd_a0;
		yEnd_a1 = (int)(ARM2_L * Math.sin(RADIAN_CONV*(theta0 + theta1)))+yEnd_a0;
		
		xEnd_a2 = -(int)(ARM3_L * Math.cos(RADIAN_CONV*(theta0 + theta1 + theta2)))+xEnd_a1;
		yEnd_a2 = (int)(ARM3_L * Math.sin(RADIAN_CONV*(theta0 + theta1 + theta2)))+yEnd_a1;
		
		
		endPoint.setX(xEnd_a2);
		endPoint.setY(yEnd_a2);
	}
	
	public void updateArms(){
		//inverse kinematic function, using the length of each arm to determine the geometric solution
		double x1, y1, x2, y2, x3, y3, x4, y4, a, b, c, c2;

		x4 = endPoint.x() - XORIGIN;
		y4 = -endPoint.y() + YORIGIN;
		
		alpha = Math.atan2(y4, x4)/RADIAN_CONV;
		//System.out.println(alpha);
		x3 = x4 - Math.cos(RADIAN_CONV*alpha)*ARM3_L;
		y3 = y4 - Math.sin(RADIAN_CONV*alpha)*ARM3_L;

		//System.out.println("x3: " + x3 + "\ny3: " + y3 + "\nx4: " + endPoint.x() + "\ny4: " + endPoint.y());
		
		c = Math.sqrt((x3*x3)+(y3*y3));
		
		a = ARM2_L;
		b = ARM1_L;
		
		//System.out.println(((c*c)-((a*a)+(b*b)))/(2.0*a*b));
		//System.out.println("\n");
		
		theta1 = -180.0+(Math.acos(((( (c*c)-((a*a)+(b*b)) )/(-2.0*a*b)))))/RADIAN_CONV;	// = 180 - acos(c^2 - (a^2 + b^2)) / (-2ab)
		
		double gam, beta;
		
		gam = -(RADIAN_CONV*180 - Math.acos(((c*c) + (a*a) - (b*b))/(2.0*a*c)))/RADIAN_CONV;
		
		beta = Math.atan2(y3, x3)/RADIAN_CONV;
		
		theta0 = beta + gam;
		
		theta2 =  -180.0 + alpha - (theta0 + theta1);
		
		/*x2 = x3 - Math.cos(RADIAN_CONV*theta1)*ARM1_L;
		y2 = y3 - Math.sin(RADIAN_CONV*theta1)*ARM1_L;
		
		x1 = x4 - x3 - x2;	//SHOULD ALWAYS EQUAL 0
		y1 = y4 - y3 - y2;
		
		System.out.println("alpha: " + alpha);
		System.out.println("beta: " + beta);
		System.out.println("gamma: " + gam);
		
		System.out.println("point 1: (" + x1 + ", " + y1 + ")");	//SHOULD ALWAYS EQUAL 0
		System.out.println("point 2: (" + x2 + ", " + y2 + ")");
		System.out.println("point 3: (" + x3 + ", " + y3 + ")");		
		System.out.println("point 4: (" + x4 + ", " + y4 + ")");		
		System.out.println(theta0 + "  " + theta1 + "  " + theta2 );*/
		
	}
	
	public void makePolygonArm(int x0, int y0, int x1, int y1, Graphics g){
		double m;
		m = (double)(y1-y0)/(double)(x1-x0); 
		
		//System.out.print(y1);
		//System.out.print("-");		
		//System.out.print(y0);
		//System.out.print("\n");
		
		//System.out.print(x1);
		//System.out.print("-");
		//System.out.print(x0);
		
		//System.out.print("\n");
		
		/*With line, find two points on this line a specific distance from end point and begging point*/
		double vector_x = x1 - x0;
		double vector_y = y1 - y0;
		
		double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));

		/*Distance from a point is x,y -/+ du*/
		double new_point_x0 = x0 + 10.0*unit_vec_x;
		double new_point_y0 = y0 + 10.0*unit_vec_y;
		
		double new_point_x1 = x1 - 10.0*unit_vec_x;
		double new_point_y1 = y1 - 10.0*unit_vec_y;
	
		/*
		Find lines along points new x0,y0 and x1,y1 perpendicular to the original line.
		*/
		double m_reciprocal;
		if(m == 0.0){
			m_reciprocal = 100;
		}
		else{
			m_reciprocal = -1/m;
		}
		
		double b_perp0 = new_point_y0 - m_reciprocal * new_point_x0; //Find b of perpendicular line for point x0,y0
		double b_perp1 = new_point_y1 - m_reciprocal * new_point_x1; //Find b of perpendicular line for point x1,y1
		
		/*Using each individual line, generate another new point, using x = 0 and find y. These points will be used to generate unit vectors for the perp lines*/
		//First Perpendicular line
		double tmp0_point_x = 0; //scared about this one
		double tmp0_point_y = m_reciprocal*tmp0_point_x + b_perp0;
		
		double perp0_vector_x = new_point_x0 - tmp0_point_x;
		double perp0_vector_y = new_point_y0 - tmp0_point_y;
		
		double perp0_unit_vec_x = perp0_vector_x / (Math.sqrt(perp0_vector_x*perp0_vector_x + perp0_vector_y*perp0_vector_y));
		double perp0_unit_vec_y = perp0_vector_y / (Math.sqrt(perp0_vector_x*perp0_vector_x + perp0_vector_y*perp0_vector_y));
		
		/*After finding unit vector, produce two more points*/
		int arm_point_x0 = (int)(new_point_x0 + 15.0*perp0_unit_vec_x);
		int arm_point_y0 = (int)(new_point_y0 + 15.0*perp0_unit_vec_y);
		
		int arm_point_x1 = (int)(new_point_x0 - 15.0*perp0_unit_vec_x);
		int arm_point_y1 = (int)(new_point_y0 - 15.0*perp0_unit_vec_y);

		//Moving on to the other perpendicular line
		double tmp1_point_x = 0;
		double tmp1_point_y = m_reciprocal*tmp1_point_x + b_perp1;
		
		double perp1_vector_x = new_point_x1 - tmp1_point_x;
		double perp1_vector_y = new_point_y1 - tmp1_point_y;
		
		double perp1_unit_vec_x = perp1_vector_x / (Math.sqrt(perp1_vector_x*perp1_vector_x + perp1_vector_y*perp1_vector_y));
		double perp1_unit_vec_y = perp1_vector_y / (Math.sqrt(perp1_vector_x*perp1_vector_x + perp1_vector_y*perp1_vector_y));
		
		/*After finding unit vector, produce two more points*/
		int arm_point_x2 = (int)(new_point_x1 + 15.0*perp1_unit_vec_x);
		int arm_point_y2 = (int)(new_point_y1 + 15.0*perp1_unit_vec_y);
		
		int arm_point_x3 = (int)(new_point_x1 - 15.0*perp1_unit_vec_x);
		int arm_point_y3 = (int)(new_point_y1 - 15.0*perp1_unit_vec_y);
		
		//Points will be used in succession as x0,y0 -> arm_point_x0,arm_point_y0 -> arm_point_x2, arm_point_y2 -> x1,y1 -> arm_point_x3,arm_point_x3 -> arm_point_x1, arm_point_y2
			
		int xpoints[] = {x0, arm_point_x0, arm_point_x2, x1, arm_point_x3, arm_point_x1};
		int ypoints[] = {y0 ,arm_point_y0, arm_point_y2, y1, arm_point_y3, arm_point_y1};
		int num_points = 6;
		
		g.drawPolygon(xpoints, ypoints, num_points);
	}
	
	public void update() {	//called implicitly to handle mouse events
		double totalLength, x4, y4;
		
		if (button0 == null) 
			return;
		try{
			if (button0.isSelected()) {
				x4 = (endPoint.x()-1) - XORIGIN;
				y4 = -endPoint.y() + YORIGIN;
				
				totalLength = Math.sqrt((x4*x4) + (y4*y4));
				
				if (totalLength > (ARM1_L + ARM2_L + ARM3_L )){
					System.out.println("INDEX OUT OF BOUNDS OF ROBOT\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
					//return;
				}
				else{
					endPoint.setX(endPoint.x() - 1);
					// implement this function
					updateArms();
					updateEnds();
					if((xEnd_a1 == XORIGIN || xEnd_a1 == XORIGIN+1 || xEnd_a1 == XORIGIN-1) && (yEnd_a1 == YORIGIN || yEnd_a1 == YORIGIN+1 || yEnd_a1 == YORIGIN-1)){ //calcs with doubles will cause ints to lose some precision 
						System.out.println("INDEX ATTEMPTING TO PASS ORIGIN\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
						endPoint.setX(endPoint.x() + 1);
						updateArms();
						updateEnds();
					}
				}
			}
			if (button1.isSelected()) {
				x4 = (endPoint.x()+1) - XORIGIN;
				y4 = -endPoint.y() + YORIGIN;
				
				totalLength = Math.sqrt((x4*x4) + (y4*y4));
				
				if (totalLength > (ARM1_L + ARM2_L + ARM3_L)){
					System.out.println("INDEX OUT OF BOUNDS OF ROBOT\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
					//return;
				}
				else{
					//update endPoint
					endPoint.setX(endPoint.x() + 1);
					updateArms();
					updateEnds();
					
					if((xEnd_a1 == XORIGIN || xEnd_a1 == XORIGIN+1 || xEnd_a1 == XORIGIN-1) && (yEnd_a1 == YORIGIN || yEnd_a1 == YORIGIN+1 || yEnd_a1 == YORIGIN-1)){ //calcs with doubles will cause ints to lose some precision 		
						System.out.println("INDEX ATTEMPTING TO PASS ORIGIN\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
						endPoint.setX(endPoint.x() - 1);
						updateArms();
						updateEnds();
					}
				}
			}
			if (button2.isSelected()) {
				x4 = endPoint.x() - XORIGIN;
				y4 = (-endPoint.y()+1) + YORIGIN;
				
				totalLength = Math.sqrt((x4*x4) + (y4*y4));
				
				if (totalLength > (ARM1_L + ARM2_L + ARM3_L)){
					System.out.println("INDEX OUT OF BOUNDS OF ROBOT\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
					//return;
				}
				else{
					//update endPoint
					endPoint.setY(endPoint.y() - 1);
					updateArms();
					updateEnds();
					if((xEnd_a1 == XORIGIN || xEnd_a1 == XORIGIN+1 || xEnd_a1 == XORIGIN-1) && (yEnd_a1 == YORIGIN || yEnd_a1 == YORIGIN+1 || yEnd_a1 == YORIGIN-1)){ //calcs with doubles will cause ints to lose some precision 
						System.out.println("INDEX ATTEMPTING TO PASS ORIGIN\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
						endPoint.setY(endPoint.y() + 1);
						updateArms();
						updateEnds();
					}
				}
			}
			if (button3.isSelected()) {
				x4 = endPoint.x() - XORIGIN;
				y4 = (-endPoint.y()-1) + YORIGIN;
				
				totalLength = Math.sqrt((x4*x4) + (y4*y4));
				
				if (totalLength > (ARM1_L + ARM2_L + ARM3_L)){
					System.out.println("INDEX OUT OF BOUNDS OF ROBOT\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
					//return;
				}
				else{
					endPoint.setY(endPoint.y() + 1);
					updateArms();
					updateEnds();
					if((xEnd_a1 == XORIGIN || xEnd_a1 == XORIGIN+1 || xEnd_a1 == XORIGIN-1) && (yEnd_a1 == YORIGIN || yEnd_a1 == YORIGIN+1 || yEnd_a1 == YORIGIN-1)){ //calcs with doubles will cause ints to lose some precision 
						System.out.println("INDEX ATTEMPTING TO PASS ORIGIN\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
						endPoint.setY(endPoint.y() - 1);
						updateArms();
						updateEnds();
					}
				}
			}
			if(button7.isSelected()){
				// change line1 here...
				theta0 = theta0 - 1;
				updateEndPoints();
				updateEnds();
				repaint();
			}
			if(button8.isSelected()){
				// change line1 here...
				theta0 = theta0 + 1;
				updateEndPoints();
				updateEnds();
				repaint();
			}
			if(button9.isSelected()){
				theta1 = theta1 - 1;
				updateEndPoints();
				updateEnds();
				repaint();
			}
			if(button10.isSelected()){
				theta1 = theta1 + 1;
				updateEndPoints();
				updateEnds();
				repaint();
			}
			if(button11.isSelected()){
				theta2 = theta2 - 1;
				updateEndPoints();
				updateEnds();
				repaint();
			}
			if(button12.isSelected()){
				theta2 = theta2 + 1;
				updateEndPoints();
				updateEnds();
				repaint();
			}
		}catch(Exception e){
			System.out.println("INDEX OUT OF BOUNDS OF ROBOT\n\tINDEX: (" + endPoint.x() + ", " + endPoint.y() + ")");
		}
	}

	public singlePanel()
	{
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e){
			e.printStackTrace();
		}
		
		if(init){	//initialization mini-function
			init = false;
			endPoint = new Point(XORIGIN, YORIGIN - (int)(ARM1_L + ARM2_L + ARM3_L), Color.RED);
			//updateArms();
			updateEnds();
			points = new ArrayList(0);
			repaint();
			
		}
		// center window on screen
		setLayout(null);
		
		label0 = new JLabel("World Control Mode");
		add(label0);
		label0.setBounds(640, 20, 120, 20);
		
		label1 = new JLabel("Joint Control Mode");
		add(label1);
		label1.setBounds(640, 300, 120, 20);
		
		// Joint 1 Counter-Clockwise button
		button0 = new JToggleButton();
		button0.setText("x++");
		button0.setVisible(true);
		button0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button1.setEnabled(!button0.isSelected());
				button2.setEnabled(!button0.isSelected());
				button3.setEnabled(!button0.isSelected());
				button7.setEnabled(!button0.isSelected());
				button8.setEnabled(!button0.isSelected());
				button9.setEnabled(!button0.isSelected());
				button10.setEnabled(!button0.isSelected());
				button11.setEnabled(!button0.isSelected());
				button12.setEnabled(!button0.isSelected());;
			}
		});
		add(button0);
		button0.setBounds(625, 50, 120, 20);
		
		// Joint 1 Clockwise
		button1 = new JToggleButton();
		button1.setText("x--");
		button1.setVisible(true);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button1.isSelected());
				button2.setEnabled(!button1.isSelected());
				button3.setEnabled(!button1.isSelected());
				button7.setEnabled(!button1.isSelected());
				button8.setEnabled(!button1.isSelected());
				button9.setEnabled(!button1.isSelected());
				button10.setEnabled(!button1.isSelected());
				button11.setEnabled(!button1.isSelected());
				button12.setEnabled(!button1.isSelected());
			}
		});
		add(button1);
		button1.setBounds(625, 70, 120, 20);
		
		// Joint 2 Counter-Clockwise button
		button2 = new JToggleButton();
		button2.setText("y++");
		button2.setVisible(true);
		button2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button2.isSelected());
				button1.setEnabled(!button2.isSelected());
				button3.setEnabled(!button2.isSelected());
				button7.setEnabled(!button2.isSelected());
				button8.setEnabled(!button2.isSelected());
				button9.setEnabled(!button2.isSelected());
				button10.setEnabled(!button2.isSelected());
				button11.setEnabled(!button2.isSelected());
				button12.setEnabled(!button2.isSelected());
			}
		});
		add(button2);
		button2.setBounds(625, 90, 120, 20);
		
		// Joint 2 Clockwise button
		button3 = new JToggleButton();
		button3.setText("y--");
		button3.setVisible(true);
		button3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button3.isSelected());
				button1.setEnabled(!button3.isSelected());
				button2.setEnabled(!button3.isSelected());
				button7.setEnabled(!button3.isSelected());
				button8.setEnabled(!button3.isSelected());
				button9.setEnabled(!button3.isSelected());
				button10.setEnabled(!button3.isSelected());
				button11.setEnabled(!button3.isSelected());
				button12.setEnabled(!button3.isSelected());
			}
		});
		add(button3);
		button3.setBounds(625, 110, 120, 20);
		
		JButton button4 = new JButton();		
		button4.setVisible(true);
		button4.setText("RED");
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{	
				if (i == 5){
					i = 0;
				}
				else{
					i = i + 1;
				}
				if (i == 0){
					button4.setText("RED");
				} else if (i == 1){
					button4.setText("BLUE");
				} else if (i == 2) {
					button4.setText("CYAN");
				} else if (i == 3) {
					button4.setText("ORANGE");
				} else if (i == 4) {
					button4.setText("GREEN");
				} else if (i == 5) {
					button4.setText("YELLOW");
				}
				paint_switch(i);
			}
		});
		add(button4);
		button4.setBounds(625, 130, 120, 20);
		
		JButton button5 = new JButton();
		button5.setText("Paint");
		button5.setVisible(true);
		button5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				paint_controller();
				repaint();
			}
		});
		add(button5);
		button5.setBounds(625, 150, 120, 20);	
	
		// Clear the window of old paint
		JButton button6 = new JButton();
		button6.setText("Erase");
		button6.setVisible(true);
		button6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				points.clear();
				painting = false;
				repaint();
			}
		});
		add(button6);
		button6.setBounds(625, 170, 120, 20);
		
		
		// Joint 1 Counter-Clockwise button
		button7 = new JToggleButton();
		button7.setText("Joint 1 CCW");
		button7.setVisible(true);
		button7.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button7.isSelected());
				button1.setEnabled(!button7.isSelected());
				button2.setEnabled(!button7.isSelected());
				button3.setEnabled(!button7.isSelected());
				button8.setEnabled(!button7.isSelected());
				button9.setEnabled(!button7.isSelected());
				button10.setEnabled(!button7.isSelected());
				button11.setEnabled(!button7.isSelected());
				button12.setEnabled(!button7.isSelected());
			}
		});
		add(button7);
		button7.setBounds(625, 330, 120, 20);
		
		// Joint 1 Clockwise
		button8 = new JToggleButton();
		button8.setText("Joint 1 CW");
		button8.setVisible(true);
		button8.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button8.isSelected());
				button1.setEnabled(!button8.isSelected());
				button2.setEnabled(!button8.isSelected());
				button3.setEnabled(!button8.isSelected());
				button7.setEnabled(!button8.isSelected());
				button9.setEnabled(!button8.isSelected());
				button10.setEnabled(!button8.isSelected());
				button11.setEnabled(!button8.isSelected());
				button12.setEnabled(!button8.isSelected());
			}
		});
		add(button8);
		button8.setBounds(625, 350, 120, 20);
		
		// Joint 2 Counter-Clockwise button
		button9 = new JToggleButton();
		button9.setText("Joint 2 CCW");
		button9.setVisible(true);
		button9.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button9.isSelected());
				button1.setEnabled(!button9.isSelected());
				button2.setEnabled(!button9.isSelected());
				button3.setEnabled(!button9.isSelected());
				button7.setEnabled(!button9.isSelected());
				button8.setEnabled(!button9.isSelected());
				button10.setEnabled(!button9.isSelected());
				button11.setEnabled(!button9.isSelected());
				button12.setEnabled(!button9.isSelected());
			}
		});
		add(button9);
		button9.setBounds(625, 370, 120, 20);
		
		// Joint 2 Clockwise button
		button10 = new JToggleButton();
		button10.setText("Joint 2 CW");
		button10.setVisible(true);
		button10.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button10.isSelected());
				button1.setEnabled(!button10.isSelected());
				button2.setEnabled(!button10.isSelected());
				button3.setEnabled(!button10.isSelected());
				button7.setEnabled(!button10.isSelected());
				button8.setEnabled(!button10.isSelected());
				button9.setEnabled(!button10.isSelected());
				button11.setEnabled(!button10.isSelected());
				button12.setEnabled(!button10.isSelected());
			}
		});
		add(button10);
		button10.setBounds(625, 390, 120, 20);
		
		
		// Joint 3 Counter-Clockwise button
		button11 = new JToggleButton();
		button11.setText("Joint 3 CCW");
		button11.setVisible(true);
		button11.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button11.isSelected());
				button1.setEnabled(!button11.isSelected());
				button2.setEnabled(!button11.isSelected());
				button3.setEnabled(!button11.isSelected());
				button7.setEnabled(!button11.isSelected());
				button8.setEnabled(!button11.isSelected());
				button9.setEnabled(!button11.isSelected());
				button10.setEnabled(!button11.isSelected());
				button12.setEnabled(!button11.isSelected());
			}
		});
		add(button11);
		button11.setBounds(625, 410, 120, 20);
		
		// Joint 3 Clockwise button
		button12 = new JToggleButton();
		button12.setText("Joint 3 CW");
		button12.setVisible(true);
		button12.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button12.isSelected());
				button1.setEnabled(!button12.isSelected());
				button2.setEnabled(!button12.isSelected());
				button3.setEnabled(!button12.isSelected());
				button7.setEnabled(!button12.isSelected());
				button8.setEnabled(!button12.isSelected());
				button9.setEnabled(!button12.isSelected());
				button10.setEnabled(!button12.isSelected());
				button11.setEnabled(!button12.isSelected());
			}
		});
		add(button12);
		button12.setBounds(625, 430, 120, 20);		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		
		g.drawPolygon(xpoints_panel0, ypoints_panel0, num_points_panel0);
		
		g.drawPolygon(xpoints_panel1, ypoints_panel1, num_points_panel1);
		
		g.drawRoundRect(XORIGIN-25, YORIGIN-25, 50, 50, 50, 50); // Base link shape
		
		//g.drawLine(XORIGIN, YORIGIN, xEnd_a0, yEnd_a0); //Only use for checking now
		makePolygonArm(XORIGIN, YORIGIN, xEnd_a0, yEnd_a0, g);	
			
		//g.drawLine(xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);	
		makePolygonArm(xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1, g);
		
		//g.drawLine(xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
		makePolygonArm(xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2, g);

		if(painting){
			//points.add(new Point(endPoint.x(), endPoint.y(), Color.BLACK));
			points.add(new Point(xEnd_a2, yEnd_a2, paint_switch(i)));
		}

		for(int i = 0; i < points.size(); i++){
			g.setColor(((Point) points.get(i)).color());
			g.fillOval(((Point) points.get(i)).x()- rad/2, ((Point) points.get(i)).y() - rad/2, rad, rad);
		}		
	}
}
