import java.awt.*;
import javax.swing.*;

public class Point { 
    private int x;    // x-coordinate
    private int y;    // y-coordinate
	private Color c;  // Color component

    // point initialized from parameters
    public Point(int x, int y, Color c) {
        this.x = x;
        this.y = y;
		this.c = c;
    }
	
	
	//mutator methods
	public void setX(int x){ this.x = x; }
	public void setY(int y){ this.y = y; }
	public void setC(Color c){ this.c = c; }
	
	
    // accessor methods
    public int x() { return x; }
    public int y() { return y; }
    public Color color() { return c;}
}
