import java.awt.*;
import java.util.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;
import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class singlePanel extends JPanel {
	private JToggleButton button0, button1, button2, button3;
	
	private static final double RADIAN_CONV = (Math.PI / 180);
	private static final int XORIGIN = 250;
	private static final int YORIGIN = 380;
	private static final double ARM1_L = 150.;
	private static final double ARM2_L = 100.;
	private static final double ARM3_L = 75.;
	
	
	// Link Length of arm 0 (AND ALL ARMS) 
	private static final int A0 = 100;
	
	private double 	theta0 = 90,
					theta1 = 90,
					theta2 = 90,
					alpha = 0;
					
	private int 	xEnd_a0 = XORIGIN,
					yEnd_a0 = YORIGIN,
					xEnd_a1	= XORIGIN,
					yEnd_a1	= YORIGIN,
					xEnd_a2	= XORIGIN,
					yEnd_a2 = YORIGIN;
					
	private Point endPoint;
	
	private boolean	painting = false;
	private ArrayList points;
	private int rad = 10, i;
	
	private boolean init = true;
	
	public void paint_controller(){
		if(painting){
			painting = false;
		}
		else{
			painting = true;
		}
	}
	
	public Color paint_switch(int x) {
		switch(x)
		{
			case 1: return Color.BLUE;
			case 2: return Color.CYAN;
			case 3: return Color.ORANGE;
			case 4: return Color.GREEN;
			case 5: return Color.YELLOW;
			default: return Color.RED;
		}
	}
					
	public void updateEnds(){
		//input arm lengths and angles, output link points
		xEnd_a0 = (int)(ARM1_L * Math.cos(RADIAN_CONV*theta0))+XORIGIN;
		yEnd_a0 = (int)(ARM1_L * Math.sin(RADIAN_CONV*theta0))+YORIGIN;
		
		xEnd_a1 = (int)(ARM2_L * Math.cos(RADIAN_CONV*theta1))+xEnd_a0;
		yEnd_a1 = (int)(ARM2_L * Math.sin(RADIAN_CONV*theta1))+yEnd_a0;
		
		xEnd_a2 = (int)(ARM3_L * Math.cos(RADIAN_CONV*theta2))+xEnd_a1;
		yEnd_a2 = (int)(ARM3_L * Math.sin(RADIAN_CONV*theta2))+yEnd_a1;
		
		System.out.println(xEnd_a0);
		
	}
	
	public void updateArms(){
		//inverse kinematic function, using the length of each arm to determine the geometric solution 
		double x3, y3, a, b, c;
		
		theta2 = Math.atan2((double)endPoint.y(), (double)endPoint.x())/RADIAN_CONV;	//equals alpha, maybe this isn't alpha?

		x3 = endPoint.x() - Math.cos(RADIAN_CONV*theta2)*ARM3_L;
		y3 = endPoint.y() - Math.sin(RADIAN_CONV*theta2)*ARM3_L;
		
		c = Math.sqrt((x3*x3)+(y3*y3));
		
		a = ARM2_L;
		b = ARM1_L;
		
		
		theta1 = -(RADIAN_CONV*180.0 - (Math.acos(RADIAN_CONV*(((c*c)-((a*a)+(b*b)))/(-2.0*a*b)))))/RADIAN_CONV;	// = 180 - acos(c^2 - (a^2 + b^2)) / (-2ab)
		//theta0 = Math.atan2(y3, x3) + Math.atan2(b, a) - RADIAN_CONV*90.0;								// = atan2(y3,x3) + atan(b, a)  - 90;
		//theta0 = Math.acos(( ( endPoint.x() - 75.0*Math.cos(theta2) ) - 100.0*Math.cos(theta1))/150.0)/RADIAN_CONV;
		//theta0 = 2 * (a / (c / 180.0 - Math.sin(theta1)));
		theta0 = 2 * Math.atan2(y3, x3);
		
		System.out.println(theta0 + "  " + theta1 + "  " + theta2 + "  " + x3 + "  " + y3 + "  " + c);
		
	}
	
	public void makePolygonArm(int x0, int y0, int x1, int y1, Graphics g){
		double m;
		m = (double)(y1-y0)/(double)(x1-x0); 
		
		//System.out.print(y1);
		//System.out.print("-");		
		//System.out.print(y0);
		//System.out.print("\n");
		
		//System.out.print(x1);
		//System.out.print("-");
		//System.out.print(x0);
		
		//System.out.print("\n");
		
		/*With line, find two points on this line a specific distance from end point and begging point*/
		double vector_x = x1 - x0;
		double vector_y = y1 - y0;
		
		double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));

		/*Distance from a point is x,y -/+ du*/
		double new_point_x0 = x0 + 10.0*unit_vec_x;
		double new_point_y0 = y0 + 10.0*unit_vec_y;
		
		double new_point_x1 = x1 - 10.0*unit_vec_x;
		double new_point_y1 = y1 - 10.0*unit_vec_y;
	
		/*
		Find lines along points new x0,y0 and x1,y1 perpendicular to the original line.
		*/
		double m_reciprocal;
		if(m == 0.0){
			m_reciprocal = 100;
		}
		else{
			m_reciprocal = -1/m;
		}
		
		double b_perp0 = new_point_y0 - m_reciprocal * new_point_x0; //Find b of perpendicular line for point x0,y0
		double b_perp1 = new_point_y1 - m_reciprocal * new_point_x1; //Find b of perpendicular line for point x1,y1
		
		/*Using each individual line, generate another new point, using x = 0 and find y. These points will be used to generate unit vectors for the perp lines*/
		//First Perpendicular line
		double tmp0_point_x = 0; //scared about this one
		double tmp0_point_y = m_reciprocal*tmp0_point_x + b_perp0;
		
		double perp0_vector_x = new_point_x0 - tmp0_point_x;
		double perp0_vector_y = new_point_y0 - tmp0_point_y;
		
		double perp0_unit_vec_x = perp0_vector_x / (Math.sqrt(perp0_vector_x*perp0_vector_x + perp0_vector_y*perp0_vector_y));
		double perp0_unit_vec_y = perp0_vector_y / (Math.sqrt(perp0_vector_x*perp0_vector_x + perp0_vector_y*perp0_vector_y));
		
		/*After finding unit vector, produce two more points*/
		int arm_point_x0 = (int)(new_point_x0 + 15.0*perp0_unit_vec_x);
		int arm_point_y0 = (int)(new_point_y0 + 15.0*perp0_unit_vec_y);
		
		int arm_point_x1 = (int)(new_point_x0 - 15.0*perp0_unit_vec_x);
		int arm_point_y1 = (int)(new_point_y0 - 15.0*perp0_unit_vec_y);

		//Moving on to the other perpendicular line
		double tmp1_point_x = 0;
		double tmp1_point_y = m_reciprocal*tmp1_point_x + b_perp1;
		
		double perp1_vector_x = new_point_x1 - tmp1_point_x;
		double perp1_vector_y = new_point_y1 - tmp1_point_y;
		
		double perp1_unit_vec_x = perp1_vector_x / (Math.sqrt(perp1_vector_x*perp1_vector_x + perp1_vector_y*perp1_vector_y));
		double perp1_unit_vec_y = perp1_vector_y / (Math.sqrt(perp1_vector_x*perp1_vector_x + perp1_vector_y*perp1_vector_y));
		
		/*After finding unit vector, produce two more points*/
		int arm_point_x2 = (int)(new_point_x1 + 15.0*perp1_unit_vec_x);
		int arm_point_y2 = (int)(new_point_y1 + 15.0*perp1_unit_vec_y);
		
		int arm_point_x3 = (int)(new_point_x1 - 15.0*perp1_unit_vec_x);
		int arm_point_y3 = (int)(new_point_y1 - 15.0*perp1_unit_vec_y);
		
		//Points will be used in succession as x0,y0 -> arm_point_x0,arm_point_y0 -> arm_point_x2, arm_point_y2 -> x1,y1 -> arm_point_x3,arm_point_x3 -> arm_point_x1, arm_point_y2
		int xpoints[] = {x0, arm_point_x0, arm_point_x2, x1, arm_point_x3, arm_point_x1};
		int ypoints[] = {y0 ,arm_point_y0, arm_point_y2, y1, arm_point_y3, arm_point_y1};
		int num_points = 6;

		g.drawPolygon(xpoints, ypoints, num_points);
	}
	
	public void update() {	//called implicitly to handle mouse events
		if (button0 == null) 
			return;
		if (button0.isSelected()) {
			//update endPoint
			endPoint.setX(endPoint.x() + 1);
			// implement this function
			updateArms();
			updateEnds();
		}
		if (button1.isSelected()) {
			//update endPoint
			endPoint.setX(endPoint.x() - 1);
			updateArms();
			updateEnds();
		}
		if (button2.isSelected()) {
			//update endPoint
			endPoint.setY(endPoint.y() - 1);
			updateArms();
			updateEnds();
		}
		if (button3.isSelected()) {
			//update endPoint
			endPoint.setY(endPoint.y() + 1);
			updateArms();
			updateEnds();
		}
	}

	public singlePanel()
	{
		if(init){	//initialization mini-function
			
			init = false;
			endPoint = new Point(XORIGIN, YORIGIN - (int)(ARM1_L + ARM2_L + ARM3_L), Color.RED);
			updateArms();
			updateEnds();
			points = new ArrayList(0);
			repaint();
			
		}
		// center window on screen
		setLayout(null);
		
		// Joint 1 Counter-Clockwise button
		button0 = new JToggleButton();
		button0.setText("x++");
		button0.setVisible(true);
		button0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button1.setEnabled(!button0.isSelected());
				button2.setEnabled(!button0.isSelected());
				button3.setEnabled(!button0.isSelected());
			}
		});
		add(button0);
		button0.setBounds(450, 10, 120, 20);
		
		// Joint 1 Clockwise
		button1 = new JToggleButton();
		button1.setText("x--");
		button1.setVisible(true);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button1.isSelected());
				button2.setEnabled(!button1.isSelected());
				button3.setEnabled(!button1.isSelected());
			}
		});
		add(button1);
		button1.setBounds(450, 30, 120, 20);
		
		// Joint 2 Counter-Clockwise button
		button2 = new JToggleButton();
		button2.setText("y++");
		button2.setVisible(true);
		button2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button2.isSelected());
				button1.setEnabled(!button2.isSelected());
				button3.setEnabled(!button2.isSelected());
			}
		});
		add(button2);
		button2.setBounds(450, 50, 120, 20);
		
		// Joint 2 Clockwise button
		button3 = new JToggleButton();
		button3.setText("y--");
		button3.setVisible(true);
		button3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				button0.setEnabled(!button3.isSelected());
				button1.setEnabled(!button3.isSelected());
				button2.setEnabled(!button3.isSelected());
			}
		});
		add(button3);
		button3.setBounds(450, 70, 120, 20);
		
		
		
		JButton button4 = new JButton();		
		button4.setVisible(true);
		button4.setText("RED");
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{	
				if (i == 5){
					i = 0;
				}
				else{
					i = i + 1;
				}
				if (i == 0){
					button4.setText("RED");
				} else if (i == 1){
					button4.setText("BLUE");
				} else if (i == 2) {
					button4.setText("CYAN");
				} else if (i == 3) {
					button4.setText("ORANGE");
				} else if (i == 4) {
					button4.setText("GREEN");
				} else if (i == 5) {
					button4.setText("YELLOW");
				}
				paint_switch(i);
			}
		});
		add(button4);
		button4.setBounds(450, 90, 120, 20);
		
		JButton button5 = new JButton();
		button5.setText("Paint");
		button5.setVisible(true);
		button5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				paint_controller();
				repaint();
			}
		});
		add(button5);
		button5.setBounds(450, 110, 120, 20);	
	
		// Clear the window of old paint
		JButton button6 = new JButton();
		button6.setText("Erase");
		button6.setVisible(true);
		button6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				points.clear();
				painting = false;
				repaint();
			}
		});
		add(button6);
		button6.setBounds(450, 130, 120, 20);
		
		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		
		g.drawRoundRect(200, 335, 80, 50, 50, 50); // Base link shape
		
		//g.drawLine(XORIGIN, YORIGIN, xEnd_a0, yEnd_a0);
		makePolygonArm(XORIGIN, YORIGIN, xEnd_a0, yEnd_a0, g);	
			
		//g.drawLine(xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);	
		makePolygonArm(xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1, g);
		
		//g.drawLine(xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
		makePolygonArm(xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2, g);

		if(painting){
			points.add(new Point(endPoint.x(), endPoint.y(), Color.BLACK));
			points.add(new Point(xEnd_a2, yEnd_a2, paint_switch(i)));
		}

		for(int i = 0; i < points.size(); i++){
			g.setColor(((Point) points.get(i)).color());
			g.fillOval(((Point) points.get(i)).x()- rad/2, ((Point) points.get(i)).y() - rad/2, rad, rad);
		}		
	}
}
