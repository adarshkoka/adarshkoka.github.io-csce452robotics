import java.awt.*;
import javax.swing.*;

public class Coordinator {
	public static final int WIDTH = 800;
	public static final int HEIGHT = 600;
	
	public static void main (String[] args)
	{
		JFrame frame = new JFrame ("Coordinator");
		frame.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		frame.setMinimumSize(new Dimension(WIDTH, HEIGHT));
		frame.setMaximumSize(new Dimension(WIDTH,HEIGHT));
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		singlePanel sp = new singlePanel();
		frame.add(sp);
		frame.setVisible(true);	
		while (true) {
		 sp.update();
		 frame.repaint();
		 try { Thread.sleep(10); } catch (Exception e) {}

		}
	}
}
