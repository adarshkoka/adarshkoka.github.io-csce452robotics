Compilation directions:
	Execute command:
		start _Run.bat
	from shell