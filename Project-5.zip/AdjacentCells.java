import java.awt.*;
import javax.swing.*;
import java.awt.image.*;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class AdjacentCells { 
    Cell c1; // Current cell
	Cell c2; // Cell that is adjacent to the current cell
	
    // point initialized from parameters
    public AdjacentCells(Cell c1, Cell c2) {
		this.c1 = c1;
		this.c2 = c2;
    }
	
	//mutator methods
	public void setCurrentCell(Cell c1){ this.c1 = c1; }
	public void setAdjacentCell(Cell c2){ this.c2 = c2; }
	
    // accessor methods
    public Cell c1() { return c1; }
    public Cell c2() { return c2; }
}
