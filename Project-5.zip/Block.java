import java.awt.*;
import javax.swing.*;
import java.awt.image.*;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class Block { 
    private double x;    // x-coordinate origin
    private double y;    // y-coordinate origin
	private double size;

	private static final double RADIAN_CONV = (Math.PI / 180.0);
	
	private int xcorner0, xcorner1, xcorner2, xcorner3; //xcorner 0 = topleft, xcorner 1 = bottomleft, xcorner 2 = bottomright, xcorner 3 = topright
	private int ycorner0, ycorner1, ycorner2, ycorner3; //ycorner 0 = topleft, ycorner 1 = bottomleft, ycorner 2 = bottomright, ycorner 3 = topright
	
	private int xpoints[];
	private int ypoints[];
	private int num_points;
	
    // point initialized from parameters
    public Block(double xorg, double yorg, double size) {
		this.x = xorg;
		this.y = yorg;
		this.size = size;
		
		double d = this.size/2.;
		
		double line_point0_x = xorg;
		double line_point0_y = yorg - d;
		
		double line_point1_x = xorg;
		double line_point1_y = yorg + d;
		
		//Corners based on the top line segment point
		xcorner0 = (int)(line_point0_x - d);
		ycorner0 = (int)(line_point0_y);
		
		xcorner3 = (int)(line_point0_x + d);
		ycorner3 = (int)(line_point0_y);
		
		//Corners based on the bottom line segment point
		xcorner1 = (int)(line_point1_x - d);
		ycorner1 = (int)(line_point1_y);
		
		xcorner2 = (int)(line_point1_x + d);
		ycorner2 = (int)(line_point1_y);
		
		int x_points[] = {xcorner0, xcorner1, xcorner2, xcorner3};
		int y_points[] = {ycorner0, ycorner1, ycorner2, ycorner3};
		
		this.xpoints = x_points;
		this.ypoints = y_points;
		this.num_points = 4;
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setSize(double size){ this.size = size; }
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public double size() { return size; }
	
	public int xcorner0() { return xcorner0; }
	public int xcorner1() { return xcorner1; }
	public int xcorner2() { return xcorner2; }
	public int xcorner3() { return xcorner3; }
	
	public int ycorner0() { return ycorner0; }
	public int ycorner1() { return ycorner1; }
	public int ycorner2() { return ycorner2; }
	public int ycorner3() { return ycorner3; }
	
	// class functions
	public void updateBody() {
		double d = size/2.;
		
		double line_point0_x = x;
		double line_point0_y = y - d;
		
		double line_point1_x = x;
		double line_point1_y = y + d;
		
		//Corners based on the top line segment point
		xcorner0 = (int)(line_point0_x - d);
		ycorner0 = (int)(line_point0_y);
		
		xcorner3 = (int)(line_point0_x + d);
		ycorner3 = (int)(line_point0_y);
		
		//Corners based on the bottom line segment point
		xcorner1 = (int)(line_point1_x - d);
		ycorner1 = (int)(line_point1_y);
		
		xcorner2 = (int)(line_point1_x + d);
		ycorner2 = (int)(line_point1_y);
		
		int x_points[] = {xcorner0, xcorner1, xcorner2, xcorner3};
		int y_points[] = {ycorner0, ycorner1, ycorner2, ycorner3};
		
		this.xpoints = x_points;
		this.ypoints = y_points;
		this.num_points = 4;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.RED);
		g.fillPolygon(this.xpoints, this.ypoints, this.num_points);
	}
}
