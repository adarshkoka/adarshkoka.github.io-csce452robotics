import java.awt.*;
import java.util.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionAdapter;
import java.awt.Point;

import javax.swing.*;
import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class singlePanel extends JPanel {
	//private JToggleButton button0, button1;
	private JButton button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11;
	private JTextField text0, text1, text2, text3;
	private	JLabel label0, label1, label2, label3;
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	private static final int XORIGIN = 300;
	private static final int YORIGIN = 380;

	private int xpoints_panel0[] = {25, 525, 525, 25};
	private int ypoints_panel0[] = {25, 25, 525, 525};
	private int num_points_panel0 = 4;
	
	//private ArrayList lightSources;
	private ArrayList cells;
	private Cell currCell;
	private Robot robot;
	private Block currBlock;
	private ArrayList blocks;
	private boolean block0 = false;
	private boolean block1 = false;
	private boolean block2 = false;
	private boolean activeRobot = false;
	private boolean placingRobot = false;
	private boolean settingRobotDest = false;
	//private Point mousePoint;
	private int paint_count;
	
	private boolean addingLight = false;
	private boolean addingVehicle = false;
	private boolean painting = false;
	private boolean init = true;
	private boolean debug = true; //testing
	private boolean showCells = false;
	
	
	//DAVID'S SECTION*****
	
	public ArrayList sortEdgeList(ArrayList edges){
		//sort edges based on edge[0] (lower y-value)
		//TODO: Write this function s.t. yEdges[0][0] < yEdges[1][0]
		
		// defines sort comparator based on 1st y-value in edge list
		
		Collections.sort(edges,new Comparator<int[]>() {
            public int compare(int[] edge1, int[] edge2) {
                return Integer.compare(edge1[0],edge2[0]);
            }
        });
		// https://stackoverflow.com/questions/4699807/sort-arraylist-of-array-in-java
		
		return(edges);
	}
	
	public ArrayList calcOpenY(ArrayList<int[]> yEdges){
		//Given sorted arraylist(bottom to top) of yedges, where no path exists (i.e. a block is there)
		//TODO: calculate y's where no object exists
		
		//Input: 
		//yEdges:
		//	[0]: [y0LOW]->[y0HIGH]	//yEdges[0][0] < yEdges[1][0]
		//	[1]: [y1LOW]->[y1HIGH]
		//	...
		
		//Output:
		//openEdges:
		//	[0]: [y0HIGH]->[y1LOW] iff: y1LOW-y0HIGH > 0
		ArrayList<int[]> openYs = new ArrayList<int[]>();
		int y0[] = new int[2];
		int y1[] = new int[2];
		int openEdge[] = new int[2];
		
		
		for (int i = 0; i < yEdges.size() - 1; i++){
			y0 = yEdges.get(i);		//smaller y[0] of the two
			y1 = yEdges.get(i+1);
			
			if (y1[0] - y0[1] > 0){
				openEdge = new int[2];
				openEdge[0] = y0[1];
				openEdge[1] = y1[0];
				openYs.add(openEdge);
			}
			else if (y1[1] - y0[1] < 0){	//then y1 is not the ceiling, and is encapsulated within y0
				for (int j = i; j < yEdges.size(); j++){
					y1 = yEdges.get(j);
					if (y1[0] - y0[1] > 0){
						openEdge = new int[2];
						openEdge[0] = y0[1];
						openEdge[1] = y1[0];
						openYs.add(openEdge);
						break;
						
					}
					//essentially skip over the next element, as it is encapsulated
					i++;
				}
				
			}
		}
		return openYs;
	}
	
	public boolean edgeEqual(int[] e1, int[] e2){
		if (e1[0] != e2[0]) return false;
		if (e1[1] != e2[1]) return false;
		return true;
	}
	
	
	public String edgeListPrint(ArrayList<int[]> edgeList){
		String out = "{ ";
		for (int i = 0; i < edgeList.size(); i++){
			out += "(";
			out += Integer.toString(edgeList.get(i)[0]);
			out += ", ";
			out += Integer.toString(edgeList.get(i)[1]);
			out += "), ";
		}
		out += " }";
		return out;
	} 
	
	public void testSortEdgeList(){
		ArrayList<int[]> testEdges = new ArrayList<int[]>();
		//populate testEdges
		int t1[] = new int[]{5, 3};
		int t2[] = new int[]{3, 3};
		int t3[] = new int[]{0, 3};
		int t4[] = new int[]{5, 2};
		
		testEdges.add(t1);
		testEdges.add(t2);
		testEdges.add(t3);
		testEdges.add(t4);
		
		
		
		System.out.println("Testing sortEdgeList():");
		System.out.println("\tInput list:    " + edgeListPrint(testEdges));
		System.out.println("\tSorted list:   " + edgeListPrint(sortEdgeList(testEdges)));
		System.out.println("\tExpected list: { (0, 3), (3, 3), (5, 3), (5, 2),  }" );
	}
	
	public void testCalcOpenY(){
		ArrayList<int[]> testEdges = new ArrayList<int[]>();
		//populate testEdges
		int t1[] = new int[]{0, 3};
		int t2[] = new int[]{4, 7};
		int t3[] = new int[]{5, 9};
		int t4[] = new int[]{10, 11};
		
		testEdges.add(t1);
		testEdges.add(t2);
		testEdges.add(t3);
		testEdges.add(t4);
		
		testEdges = sortEdgeList(testEdges);
		
		System.out.println("Testing calcOpenY():");
		System.out.println("\tInput list:    " + edgeListPrint(testEdges));
		System.out.println("\tyCalc list:    " + edgeListPrint(calcOpenY(testEdges)));
		System.out.println("\tExpected list: { (3, 4), (9, 10),  }" );
		testEdges.clear();
		
		
		t1 = new int[]{0, 0};
		t2 = new int[]{500, 500};
		t3 = new int[]{5, 8};
		t4 = new int[]{3, 6};
		
		testEdges.add(t1);
		testEdges.add(t2);
		testEdges.add(t3);
		
		testEdges = sortEdgeList(testEdges);
		
		System.out.println("Testing calcOpenY():");
		System.out.println("\tInput list:    " + edgeListPrint(testEdges));
		System.out.println("\tyCalc list:    " + edgeListPrint(calcOpenY(testEdges)));
		
		
		testEdges.add(t4);
		
		testEdges = sortEdgeList(testEdges);
		
		System.out.println("Testing calcOpenY():");
		System.out.println("\tInput list:    " + edgeListPrint(testEdges));
		System.out.println("\tyCalc list:    " + edgeListPrint(calcOpenY(testEdges)));
		testEdges.clear();
		
	}
	
	public void testEdgeEqual(){
		int e1[] = new int[]{0, 1};
		int e2[] = new int[]{0, 1};
		int e3[] = new int[]{1, 1};
		int e4[] = new int[]{0, 0};
		
		System.out.println("Testing edgeEqual():");
		System.out.println("\tTest1:      " + edgeEqual(e1, e2));
		System.out.println("\t\tExpected:   true");
		System.out.println("\tTest2:      " + edgeEqual(e1, e3));
		System.out.println("\t\tExpected:   false");
		System.out.println("\tTest3:      " + edgeEqual(e1, e4));
		System.out.println("\t\tExpected:   false");

		
	}
	
	public ArrayList makeCells(ArrayList<Block> blocks){
		ArrayList<Cell> cells = new ArrayList<Cell>();
		ArrayList<int[]> yEdges = new ArrayList<int[]>();	//list of y-values for object edges currently being processed
		ArrayList<int[]> openYs = new ArrayList<int[]>();	//list of y-values where no objects exist
		int[] openX = new int[2];
		
		int windowmin = 25;
		int windowmax = 525;
		
		int[] edge = {windowmin, windowmin};
		yEdges.add(edge);

		edge = new int[] {windowmax, windowmax};
		yEdges.add(edge);
		
		openYs = calcOpenY(yEdges);
		
		
		openX[0] = windowmin;
		
		int[] xpoints, ypoints;
		int id;
		Block block;
		Cell cell;
		//for every x value, check if any of the blocks have a matching x at one of their corners;
		//	if so, 
		//		if left edge,
		//			add leftyedge to yEdges
		//			reevaluate free y's
		//			reevaluate free x's
		//			add new cells
		//		if right edge,
		//			pop rightyedge from yEdges
		//			re reevaluate free y's
		//			reevaluate free x's
		//			add new cells
		
		for (int i = windowmin; i < windowmax; i++){	//for every x value
			for(int j = 0; j < blocks.size(); j++){		//for every block
				block = blocks.get(j);
				if (block.xcorner0() == i || block.xcorner3() == i){	//if block left or right edge == this x
					if (block.xcorner0() == i){	//LEFT edge
						edge = new int[]{block.ycorner0(), block.ycorner1()};
						yEdges.add(edge);
						yEdges = sortEdgeList(yEdges);
						openX[1] = i;
						
						//make cells, with openX as the edges x coordinates openX[0] < openX[1]
						//and openYs as the y coordinates
						//***
						for(int y = 0; y < openYs.size(); y++){
							id = Integer.parseInt(Integer.toString(openX[0]) + Integer.toString(openYs.get(y)[1]));	//id is top left corner
							xpoints = new int[]{openX[0], openX[0], openX[1], openX[1]};
							ypoints = new int[]{openYs.get(y)[0], openYs.get(y)[1], openYs.get(y)[1], openYs.get(y)[0]};
							cell = new Cell(xpoints, ypoints, id);
							cells.add(cell);
						}
						
						//***
						//THEN
						openYs = calcOpenY(yEdges);
						openX[0] = i;
					}
					else{	//RIGHT edge
							//need to check if any y's are higher or lower than it 
						edge = new int[]{block.ycorner0(), block.ycorner1()};
						//search yEdges for edge; when found, pop edge from list 
						//TODO:re-sort yEdges, then recalculate openY, openX, as done before and make new Cells
						for (int k = 0; k < yEdges.size(); k++){
							if (edgeEqual(yEdges.get(k), edge)){
								yEdges.remove(k);
							}
						}
						//pop yEdges[edge] from yEdges, THEN
						yEdges = sortEdgeList(yEdges);
						
						openX[1] = i;
						
						for(int y = 0; y < openYs.size(); y++){
							
							id = Integer.parseInt(Integer.toString(openX[0]) + Integer.toString(openYs.get(y)[1]));	//id is top left corner
							xpoints = new int[]{openX[0], openX[0], openX[1], openX[1]};
							ypoints = new int[]{openYs.get(y)[0], openYs.get(y)[1], openYs.get(y)[1], openYs.get(y)[0]};
							cell = new Cell(xpoints, ypoints, id);
							cells.add(cell);
						}
						openYs = calcOpenY(yEdges);
						
						openX[0] = i;
						
					}
				}
			}
		}
		//add final calculation of openx's once final pixel is reached
		//***
		yEdges = sortEdgeList(yEdges);
		openYs = calcOpenY(yEdges);
		openX[1] = windowmax;
		for(int y = 0; y < openYs.size(); y++){
			id = Integer.parseInt(Integer.toString(openX[0]) + Integer.toString(openYs.get(y)[1]));	//id is top left corner
			xpoints = new int[]{openX[0], openX[0], openX[1], openX[1]};
			ypoints = new int[]{openYs.get(y)[0], openYs.get(y)[1], openYs.get(y)[1], openYs.get(y)[0]};
			cell = new Cell(xpoints, ypoints, id);
			cells.add(cell);
		}
		
		//***
		//THEN!
		//ArrayList Cell is populated, return
		return cells;
	}
	//DAVID'S SECTION***
	//-------------------------
	
	// CSL
	// function computes adjacency for all cells in member list "cells"
	// adjacent cells are specified left edge -> right edge of cell only
	public void populateAdjacencyLists(ArrayList<Cell> cells) {
		
		Cell 	currentCell;
		int		currentRightX;
		int 	currentY1;
		int		currentY2;
	
		Cell 	otherCell;
		int		otherLeftX;
		int		otherY1;
		int		otherY2;
		
		for(int i=0; i<cells.size(); i++) {
			// finding adjacent cells to cells[i]
			currentCell 	= cells.get(i);
			currentRightX 	= currentCell.xcorner3();
			currentY1 		= currentCell.ycorner0();
			currentY2 		= currentCell.ycorner1();
			for(int j=0; j<cells.size(); j++) {
				// cell cannot be adjacent to itself
				if(j != i) {
					otherCell 		= cells.get(j);
					otherLeftX 		= otherCell.xcorner0();
					otherY1			=otherCell.ycorner0();
					otherY2			=otherCell.ycorner1();
					// checks if new cell is left -> right adjacent with current 
					if(currentRightX == otherLeftX) {
						if( yIsAdjacent(currentY1,currentY2,otherY1,otherY2) ) {
							// cell is adjacent on both x and y axes, add to list
							currentCell.setAdjacentCells(otherCell);
						}
					}
				}
			// other cell loop
			}
		// current cell loop
		}
		
		return;
	}
	public boolean yIsAdjacent(int currentY1, int currentY2, int otherY1, int otherY2) {
		if( (currentY1<=otherY1)&&(otherY1<=currentY2) || (currentY1<=otherY2)&&(otherY2<=currentY2) ) {
			// cells intersect on y-axis
			return(true);
		}
		// no intersection of cells on y-axis
		return(false);
	}
	// CSL
	
	public Color paint_switch(int x) {
		switch(x)
		{
			case 1: return Color.RED;
			case 2: return Color.ORANGE;
			case 3: return Color.YELLOW;
			case 4: return Color.GREEN;
			case 5: return Color.BLUE;
			case 6: return Color.MAGENTA;
			default: return Color.BLACK;
		}
	}
	
	public void paint_controller(){
		if(painting){
			painting = false;
		}
		else{
			painting = true;
		}
	}
	
	public void update() {	//called implicitly to handle mouse events

	}

	public singlePanel()
	{
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e){
			e.printStackTrace();
		}
		
		if(init){	//initialization mini-function
			init = false;
			
			addMouseListener(new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e){
						if(addingLight){
							/*Making Light Sources*/
							//lightSources.add(new LightSource(e.getX(), e.getY()));
						}
					}
					public void mouseExited(MouseEvent e){

					}
					public void mouseEntered(MouseEvent e){

					}
					public void mousePressed(MouseEvent e){
						if(block0){
							ArrayList checkBlocks = new ArrayList(0);
							for (int i = 0; i < blocks.size(); i++) {
								if (((Block) blocks.get(i)).size() != 200.0){
									checkBlocks.add((Block) blocks.get(i));
								}
							}
							blocks = checkBlocks;
							currBlock = new Block((double)e.getX(), (double)e.getY(), 200.0);
							/*Check for out of bounds*/
							if ((currBlock.x()-100.0) < 25.0) {
								currBlock.setX(25.0+100.0);
							}
							if ((currBlock.x()+100.0) > 525.0) {
								currBlock.setX(525.0-100.0);
							}
							if ((currBlock.y()-100.0) < 25.0) {
								currBlock.setY(25.0+100.0);
							}
							if ((currBlock.y()+100.0) > 525.0) {
								currBlock.setY(525.0-100.0);
							}
							blocks.add(currBlock);
							currBlock.updateBody();
							//mousePoint = e.getPoint();
						}
						else if(block1){
							ArrayList checkBlocks = new ArrayList(0);
							for (int i = 0; i < blocks.size(); i++) {
								if (((Block) blocks.get(i)).size() != 150.0){
									checkBlocks.add((Block) blocks.get(i));
								}
							}
							
							blocks = checkBlocks;
							currBlock = new Block((double)e.getX(), (double)e.getY(), 150.0);
							/*Check for out of bounds*/
							if ((currBlock.x()-75.0) < 25.0) {
								currBlock.setX(25.0+75.0);
							}
							if ((currBlock.x()+75.0) > 525.0) {
								currBlock.setX(525.0-75.0);
							}
							if ((currBlock.y()-75.0) < 25.0) {
								currBlock.setY(25.0+75.0);
							}
							if ((currBlock.y()+75.0) > 525.0) {
								currBlock.setY(525.0-75.0);
							}
							blocks.add(currBlock);
							currBlock.updateBody();
						}
						else if(block2){
							ArrayList checkBlocks = new ArrayList(0);
							for (int i = 0; i < blocks.size(); i++) {
								if (((Block) blocks.get(i)).size() != 100.0){
									checkBlocks.add((Block) blocks.get(i));
								}
							}
							blocks = checkBlocks;
							currBlock = new Block((double)e.getX(), (double)e.getY(), 100.0);
							/*Check for out of bounds*/
							if ((currBlock.x()-50.0) < 25.0) {
								currBlock.setX(25.0+50.0);
							}
							if ((currBlock.x()+50.0) > 525.0) {
								currBlock.setX(525.0-50.0);
							}
							if ((currBlock.y()-50.0) < 25.0) {
								currBlock.setY(25.0+75.0);
							}
							if ((currBlock.y()+50.0) > 525.0) {
								currBlock.setY(525.0-50.0);
							}
							blocks.add(currBlock);
							currBlock.updateBody();
						}
						else if(placingRobot){
							robot = new Robot((double)e.getX(), (double)e.getY());
							activeRobot = true;
						}
						else if(settingRobotDest){
							robot.setDestX((double)e.getX());
							robot.setDestY((double)e.getY());
							robot.destIsSet(true);
						}
						else {
							
						}
					} 
					public void mouseReleased(MouseEvent e){

					}		
			});
			
			addMouseMotionListener(new MouseMotionAdapter() {
				@Override
				public void mouseDragged(MouseEvent e) {
					if (block0 || block1 || block2){
						currBlock.setX(e.getX());
						currBlock.setY(e.getY());
						
						if (block0){
							/*Check for out of bounds*/
							if ((currBlock.x()-100.0) < 25.0) {
								currBlock.setX(25.0+100.0);
							}
							if ((currBlock.x()+100.0) > 525.0) {
								currBlock.setX(525.0-100.0);
							}
							if ((currBlock.y()-100.0) < 25.0) {
								currBlock.setY(25.0+100.0);
							}
							if ((currBlock.y()+100.0) > 525.0) {
								currBlock.setY(525.0-100.0);
							}
							
						}
						else if (block1){
							/*Check for out of bounds*/
							if ((currBlock.x()-75.0) < 25.0) {
								currBlock.setX(25.0+75.0);
							}
							if ((currBlock.x()+75.0) > 525.0) {
								currBlock.setX(525.0-75.0);
							}
							if ((currBlock.y()-75.0) < 25.0) {
								currBlock.setY(25.0+75.0);
							}
							if ((currBlock.y()+75.0) > 525.0) {
								currBlock.setY(525.0-75.0);
							}
						}
						else{
							/*Check for out of bounds*/
							if ((currBlock.x()-50.0) < 25.0) {
								currBlock.setX(25.0+50.0);
							}
							if ((currBlock.x()+50.0) > 525.0) {
								currBlock.setX(525.0-50.0);
							}
							if ((currBlock.y()-50.0) < 25.0) {
								currBlock.setY(25.0+75.0);
							}
							if ((currBlock.y()+50.0) > 525.0) {
								currBlock.setY(525.0-50.0);
							}
						}
						
						currBlock.updateBody();
						repaint();
					}
				}
			});

			blocks = new ArrayList(0);
			cells = new ArrayList(0);
			
			repaint();
		}
		// center window on screen
		setLayout(null);
		
		label0 = new JLabel("Environment Controller");
		add(label0);
		label0.setBounds(550, 20, 120, 20);
		
		//Adding Block 1
		button0 = new JButton();
		button0.setText("Place Block 1");
		button0.setVisible(true);
		button0.setFocusable(false);
		button0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				block0 = true;
				block1 = false;
				block2 = false;
				placingRobot = false;
				settingRobotDest = false;
				testSortEdgeList();
				testCalcOpenY();
				testEdgeEqual();
			}
		});
		add(button0);
		button0.setBounds(550, 190, 120, 20);
		
		//Adding Block 2
		button1 = new JButton();
		button1.setText("Place Block 2");
		button1.setVisible(true);
		button1.setFocusable(false);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				block0 = false;
				block1 = true;
				block2 = false;
				placingRobot = false;
				settingRobotDest = false;
			}
		});
		add(button1);
		button1.setBounds(550, 220, 120, 20);
		
		//Adding Block 3
		button2 = new JButton();
		button2.setText("Place Block 3");
		button2.setVisible(true);
		button2.setFocusable(false);
		button2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				block0 = false;
				block1 = false;
				block2 = true;
				placingRobot = false;
				settingRobotDest = false;
			}
		});
		add(button2);
		button2.setBounds(550, 250, 120, 20);
		
		//Place robot source
		button3 = new JButton();
		button3.setText("Place Robot");
		button3.setVisible(true);
		button3.setFocusable(false);
		button3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				block0 = false;
				block1 = false;
				block2 = false;
				placingRobot = true;
				settingRobotDest = false;
			}
		});
		add(button3);
		button3.setBounds(550, 280, 120, 20);
		
		//Set robot destination
		button4 = new JButton();
		button4.setText("Set Robot Destination");
		button4.setVisible(true);
		button4.setFocusable(false);
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				block0 = false;
				block1 = false;
				block2 = false;
				placingRobot = false;
				settingRobotDest = true;
			}
		});
		add(button4);
		button4.setBounds(550, 310, 120, 20);
		
		//Find Path
		button5 = new JButton();
		button5.setText("Find Path");
		button5.setVisible(true);
		button5.setFocusable(false);
		button5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if (robot.destIsSet()){
					//createCells();
					cells = makeCells(blocks);
					populateAdjacencyLists(cells);
					for (int k = 0; k < cells.size(); k++){
						System.out.println(cells.get(k).toString());
					}
					
					robot.createPath(cells);
					repaint();
				}
			}
		});
		add(button5);
		button5.setBounds(550, 340, 120, 20);
		
		
		//Show Cells
		button6 = new JButton();
		button6.setText("Show Cells");
		button6.setVisible(true);
		button6.setFocusable(false);
		button6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				//createCells();
				cells = makeCells(blocks);
				populateAdjacencyLists(cells);
				if (debug == true){
					for (int k = 0; k < cells.size(); k++){
						System.out.println(cells.get(k).toString());
					}
				}
				showCells = showCells? false : true;
				repaint();
			
			}
		});
		add(button6);
		button6.setBounds(550, 370, 120, 20);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		
		g.drawPolygon(xpoints_panel0, ypoints_panel0, num_points_panel0);

		// for(int i = 0; i < lightSources.size(); i++){
			// g.drawImage(((LightSource) lightSources.get(i)).img(), ((LightSource) lightSources.get(i)).x()-((LightSource) lightSources.get(i)).imgW()/2, ((LightSource) lightSources.get(i)).y()-((LightSource) lightSources.get(i)).imgH()/2, null);
		// }

		// if(painting){
			// g.setColor(paint_switch(paint_count));
		// }
		
		for(int j = 0; j < blocks.size(); j++){
			 ((Block) blocks.get(j)).draw(g);
		}
		if(activeRobot){
			robot.draw(g);
		}
		if(showCells){
			for(int k = 0; k < cells.size(); k++){
				((Cell) cells.get(k)).draw(g);
			}
		}
		
	}
}
