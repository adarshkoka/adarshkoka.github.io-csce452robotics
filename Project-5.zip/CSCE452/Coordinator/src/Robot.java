import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.image.*;
import java.lang.Object.*;
import java.awt.Point;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class Robot { 
    private double x;    // x-coordinate origin
    private double y;    // y-coordinate origin
	private double dest_x;
	private double dest_y;
	private int rad = 5;
	private boolean destIsSet = false;
	private boolean drawPath = false;
	
	private int x_points[];
	private int y_points[];
	private ArrayList x_points_array;
	private ArrayList y_points_array;
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	
	private ArrayList pathPts;
	
    // point initialized from parameters
    public Robot(double xorg, double yorg) {
		this.x = xorg;
		this.y = yorg;
		this.pathPts = new ArrayList(0);

		this.x_points_array = new ArrayList(0);
		this.y_points_array = new ArrayList(0);
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setDestX(double x) { this.dest_x = x; }
	public void setDestY(double y) { this.dest_y = y; }
	public void destIsSet(boolean setter) { this.destIsSet = setter; }
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public double dest_x() { return dest_x; }
	public double dest_y() { return dest_y; }
	public boolean destIsSet() { return destIsSet; }
	
	public void createPath(ArrayList cells) {
		double tmpx, tmpy;
		/*The hacky stuff lol*/
		if(dest_x < x){
			tmpx = x;
			tmpy = y;
			
			x = dest_x;
			y = dest_y;
			
			dest_x = tmpx;
			dest_y = tmpy;
		}
		
		/*Check which cell the destination is in*/
		int x_points[] = {0, 0, 0, 0};
		int y_points[] = {0, 0, 0, 0};
		Cell destCell = new Cell(x_points, y_points, 69); //dummy cells
		Cell srcCell = new Cell(x_points, y_points, 69);
		for(int i = 0; i < cells.size(); i++){
			//bounds checking to see if inside a cell, have to use equal otherwise we could run into edge case where dest cell isn't set.
			if(dest_x <= ((Cell)cells.get(i)).xcorner3() && dest_x >= ((Cell)cells.get(i)).xcorner0() && dest_y <= ((Cell)cells.get(i)).ycorner1() && dest_y >= ((Cell)cells.get(i)).xcorner0()){
				destCell = (Cell)cells.get(i);
			}
			if(x <= ((Cell)cells.get(i)).xcorner3() && x >= ((Cell)cells.get(i)).xcorner0() && y <= ((Cell)cells.get(i)).ycorner1() && y >= ((Cell)cells.get(i)).xcorner0()){
				srcCell = (Cell)cells.get(i);
			}
		}
		
		//int count = srcCell.adjacentCells().size(); //When there are no more options from the srcCell, quit the loop as there is no solution
		Cell orgCell = srcCell;
		Cell nextCell = new Cell(x_points, y_points, 69);
		int nextCellId, rnd, count;
		count = 0;
		int boundary = 25000;
		
		ArrayList cellIds = new ArrayList(0); //cellIds of path
		cellIds.add(srcCell.id());
		
		System.out.println("Finding Path");
		if(cells.size() < 6){
			boundary = 10000;
		}
		else{
			boundary = 100000;
		}
		while (srcCell != destCell && count < boundary){
			/*Go down the path of */
			//System.out.println("Looping");
			System.out.println(srcCell.adjacentCells().size());
			if(srcCell.adjacentCells().size() > 0){
				//System.out.println("Adding a new CellId");
				/*Determine the Cell the curr "Point" is*/
				rnd = new Random().nextInt(srcCell.adjacentCells().size());
				//System.out.println("random it: " + rnd);
				nextCellId = ((Cell) (srcCell.adjacentCells().get(rnd))).id();
				
				for(int c = 0; c < cells.size(); c++){
					if(((Cell) (cells.get(c))).id() == nextCellId){
						nextCell = (Cell) (cells.get(c));
						//System.out.println("Cellid: " + nextCellId + " " + nextCell.adjacentCells().size());
					}
				}
				cellIds.add(nextCellId);
				srcCell = nextCell; //Theoretically, should reach srcCell to dstCell and exit this loop immediately, srcCell will have adjacentCells.size of 0 
			}
			else{
				if(srcCell != destCell){
					//System.out.println("Retrying");
					srcCell = orgCell;
					cellIds.clear();
					cellIds.add(srcCell.id());
				}
			}
			count = count + 1;
		}
		double dx, dy, theta;
		/*Draw using cellIds()*/
		x_points_array.add((int)x);
		y_points_array.add((int)y);
		if(cellIds.size() > 1){
			cellIds.add(destCell.id());
			System.out.println("Drawing Path with cellId size: " + cellIds.size());
			
			//Debugging
			System.out.println("\n");
			for(int i = 0; i < cellIds.size(); i++){
				for(int c = 0; c < cells.size(); c++){
					if(((Cell) cells.get(c)).id() == (int) cellIds.get(i)){
						System.out.println(((Cell) cells.get(c)).toString());
					}
				}
			}
			
			if(cellIds.size() <= 2){
				x_points_array.add((int)dest_x);
				y_points_array.add((int)dest_y);
			}
			else{
				/*src to the edge midpoint right of the first cell*/
				Cell currCellDraw = orgCell;
				Cell nextCellDraw = destCell;
				tmpx = x;
				tmpy = y;
				
				for(int i = 0; i < cellIds.size()-2; i++){ //only do the middle portions of CellIds
					/*For each cell, draw from x, y to the next midpoints*/
					for(int c = 0; c < cells.size(); c++){
						if(((Cell) cells.get(c)).id() == (int) cellIds.get(i)){
							currCellDraw = (Cell) cells.get(c);
						}
					}
					for(int c2 = 0; c2 < cells.size(); c2++){
					 	if(((Cell) cells.get(c2)).id() == (int) cellIds.get(i+1)){
							nextCellDraw = (Cell) cells.get(c2);
						}
					}
					
					/*Draw line*/
					//go to right mide point
					x_points_array.add((int)currCellDraw.rightMid());
					y_points_array.add((int)currCellDraw.y());
					
					//System.out.println(currCellDraw.y() + "\n");

					//then go to left point of next
					x_points_array.add((int)nextCellDraw.leftMid());
					y_points_array.add((int)nextCellDraw.y());
					
					//System.out.println(nextCellDraw.y() + "\n");
				}
				
				/*Draw last part from x,y to the dest_x, dest_y*/
				x_points_array.add((int)dest_x);
				y_points_array.add((int)dest_y);
			}
			
			this.x_points = new int[x_points_array.size()];
			for(int i = 0; i < x_points_array.size(); i++) {
				if (x_points_array.get(i) != null) {
					this.x_points[i] = (int) x_points_array.get(i);
				}
			}
			this.y_points = new int[y_points_array.size()];
			for(int i = 0; i < y_points_array.size(); i++) {
				if (y_points_array.get(i) != null) {
					this.y_points[i] = (int) y_points_array.get(i);
				}
			}
			this.drawPath = true;
		}
		else{
			/*No solution portion*/
			System.out.println("Couldn't find a path");
		}
	}
	
	/*Draw vehicle AND all of its components*/
	public void draw(Graphics g) {
		g.setColor(Color.BLUE);
		g.fillOval((int) x - rad/2, (int) y - rad/2, rad, rad);
		
		if(destIsSet){
			g.setColor(Color.BLUE);
			// for(int i = 10; i < pathPts.size(); i+=10){
				// g.fillOval((int)((Point) pathPts.get(i)).getX() - rad/2, (int)((Point) pathPts.get(i)).getY() - rad/2, rad, rad);
			// }
			if(drawPath){
				g.drawPolyline(x_points, y_points, x_points.length);
			}
			g.fillOval((int) dest_x - rad/2, (int) dest_y - rad/2, rad, rad);
		}
	}
}
