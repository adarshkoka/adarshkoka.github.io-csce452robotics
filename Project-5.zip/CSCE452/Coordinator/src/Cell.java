import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.image.*;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class Cell { 
    private double x;    // x-coordinate origin
    private double y;    // y-coordinate origin
	private int id;
	private double h;
	private double w;
	private double leftEdgeMidPtX, rightEdgeMidPtX;

	private static final double RADIAN_CONV = (Math.PI / 180.0);
	
	private int xcorner0, xcorner1, xcorner2, xcorner3; //xcorner 0 = topleft, xcorner 1 = bottomleft, xcorner 2 = bottomright, xcorner 3 = topright
	private int ycorner0, ycorner1, ycorner2, ycorner3; //ycorner 0 = topleft, ycorner 1 = bottomleft, ycorner 2 = bottomright, ycorner 3 = topright
	
	private int xpoints[];
	private int ypoints[];
	private int num_points;
	
	private ArrayList adjacentCells;
	
    // point initialized from parameters
    public Cell(int[] x_points, int[] y_points, int id) {
		this.id = id;
		this.adjacentCells = new ArrayList(0);
		this.xpoints = x_points;
		this.ypoints = y_points;
		this.num_points = 4;
		
		this.xcorner0 = x_points[0];
		this.xcorner1 = x_points[1];
		this.xcorner2 = x_points[2];
		this.xcorner3 = x_points[3];
		
		this.ycorner0 = y_points[0];
		this.ycorner1 = y_points[1];
		this.ycorner2 = y_points[2];
		this.ycorner3 = y_points[3];
		
		this.h = this.ycorner1 - this.ycorner0;
		this.w = this.xcorner1 - this.xcorner0;
		
		this.leftEdgeMidPtX = (double)this.xcorner0;
		this.rightEdgeMidPtX = (double)this.xcorner3;
		this.x = (double)this.xcorner0 + this.w/2.;
		this.y = (double)this.ycorner0 + this.h/2.;
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setId(int id) { this.id = id; }
	public void setAdjacentCells(Cell c) {
			for(int i=0; i<this.adjacentCells.size(); i++){
				if(c.id() == ((Cell) this.adjacentCells.get(i)).id()){
					return;
				}
			}
			this.adjacentCells.add(c); 
	}
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public double leftMid() { return leftEdgeMidPtX; }
	public double rightMid() { return rightEdgeMidPtX; }
	public int id() { return id; }
	
	public int xcorner0() { return xcorner0; }
	public int xcorner1() { return xcorner1; }
	public int xcorner2() { return xcorner2; }
	public int xcorner3() { return xcorner3; }
	
	public int ycorner0() { return ycorner0; }
	public int ycorner1() { return ycorner1; }
	public int ycorner2() { return ycorner2; }
	public int ycorner3() { return ycorner3; }
	
	public ArrayList adjacentCells() { return adjacentCells; }
	
	public String toString(){
		String out = "Cell \"" + Integer.toString(id) + "\"";
		out += "\n\tTop Left: (" + xcorner0 + ", " + ycorner0 + ")";
		out += "\n\tBottom Left: (" + xcorner1 + ", " + ycorner1 + ")";
		out += "\n\tBottom Right: (" + xcorner2 + ", " + ycorner2 + ")";
		out += "\n\tTop Right: (" + xcorner3 + ", " + ycorner3 + ")\n";
		out += "\n\tLeft/Right Mid Point: (" + leftEdgeMidPtX + ", " + rightEdgeMidPtX + ")\n";
		out += "\n\torigin x, y: (" + x + ", " + y + ")\n";
		out += "\n\tAdjacent Cells: ";
		for (int i = 0; i < adjacentCells.size(); i++){
			out += "\n\tCell: " + ((Cell)adjacentCells.get(i)).id();
		}
		out += "\n";
		return out;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.GREEN);
		g.drawPolygon(this.xpoints, this.ypoints, this.num_points);
	}
}
