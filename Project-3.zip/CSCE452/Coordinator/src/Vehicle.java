import java.awt.*;
import javax.swing.*;
import java.awt.image.*;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class Vehicle { 
    private double x;    // x-coordinate origin
    private double y;    // y-coordinate origin
	private double theta; // angle of vehicle
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);

	private int xcorner0, xcorner1, xcorner2, xcorner3; //xcorner 0 = topleft, xcorner 1 = bottomleft, xcorner 2 = bottomright, xcorner 3 = topright
	private int ycorner0, ycorner1, ycorner2, ycorner3; //ycorner 0 = topleft, ycorner 1 = bottomleft, ycorner 2 = bottomright, ycorner 3 = topright
	
	private int xpoints[];
	private int ypoints[];
	private int num_points;
	
	private int[][] k = new int[][]{ {7, 3}, {3, 7} };
	
	Wheel w1, w2; //Left wheel is w1, right wheel is w2
	Sensor s1, s2; // Left sensor is s1, right sensor is s2
	
    // point initialized from parameters
    public Vehicle(double xorg, double yorg) {
		this.theta = 90.0;
		this.x = xorg;
		this.y = yorg;
		
		double d = 20.0;
		
		double line_point0_x = xorg + d*Math.cos(RADIAN_CONV*theta);
		double line_point0_y = yorg - d*Math.sin(RADIAN_CONV*theta);
		
		double line_point1_x = xorg - d*Math.cos(RADIAN_CONV*theta);
		double line_point1_y = yorg + d*Math.sin(RADIAN_CONV*theta);
		
		//Corners based on the top line segment point
		xcorner0 = (int)(line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner0 = (int)(line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner3 = (int)(line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner3 = (int)(line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		//Corners based on the bottom line segment point
		xcorner1 = (int)(line_point1_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner1 = (int)(line_point1_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner2 = (int)(line_point1_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner2 = (int)(line_point1_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		int x_points[] = {xcorner0, xcorner1, xcorner2, xcorner3};
		int y_points[] = {ycorner0, ycorner1, ycorner2, ycorner3};
		
		this.xpoints = x_points;
		this.ypoints = y_points;
		this.num_points = 4;
		
		this.addWheels();
		this.addSensors();
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setTheta(double theta) { this.theta = theta; }
	public void setK(int[][] k) { this.k = k; }
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public double theta() { return theta; }
	public int[][] k() { return k; }
	
	public void addWheels(){
		w1 = new Wheel(xcorner1, ycorner1, true); // left
		w2 = new Wheel(xcorner2, ycorner2, false); // right
	}
	
	public void addSensors(){
		/*Find starting point for sensor on vehicle*/
		double d = 20.0;
		
		double line_point0_x = (x + d*Math.cos(RADIAN_CONV*theta));
		double line_point0_y = y - d*Math.sin(RADIAN_CONV*theta);
		
		double vector_x = (line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0))) - (line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner0 - xcorner3
		double vector_y = (line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0))) - (line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner0 - ycorner3
		
		double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));

		/*Distance from a point is x,y -/+ du*/
		s1 = new Sensor((line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0))) - 5.0*unit_vec_x, (line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0))) - 5.0*unit_vec_y); //xcorner0 - unitvecx, ycorner0 - unitvecy
		s2 = new Sensor((line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0))) + 5.0*unit_vec_x, (line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0))) + 5.0*unit_vec_y); //xcorner3 - unitvecx, ycorner3 - unitvecy
	}
	
	/*Update vehicle position/orientation? AND all of its components*/
	public void updateBody() {
		double d = 20.0;
		
		double line_point0_x = x + d*Math.cos(RADIAN_CONV*theta);
		double line_point0_y = y - d*Math.sin(RADIAN_CONV*theta);
		
		double line_point1_x = x - d*Math.cos(RADIAN_CONV*theta);
		double line_point1_y = y + d*Math.sin(RADIAN_CONV*theta);
		
		//Corners based on the top line segment point
		xcorner0 = (int)(line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner0 = (int)(line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner3 = (int)(line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner3 = (int)(line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		//Corners based on the bottom line segment point
		xcorner1 = (int)(line_point1_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner1 = (int)(line_point1_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner2 = (int)(line_point1_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner2 = (int)(line_point1_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		int x_points[] = {xcorner0, xcorner1, xcorner2, xcorner3};
		int y_points[] = {ycorner0, ycorner1, ycorner2, ycorner3};
		
		this.xpoints = x_points;
		this.ypoints = y_points;
		this.num_points = 4;
		
		/*Update Wheel Parameters*/
		this.w1.setX(line_point1_x - d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner1
		this.w1.setY(line_point1_y + d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner1
		this.w1.setTheta(theta);
		
		this.w2.setX(line_point1_x + d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner2
		this.w2.setY(line_point1_y - d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner2
		this.w2.setTheta(theta);
		
		this.w1.updateBody();
		this.w2.updateBody();
		
		/*Update Sensor Parameters*/
		double vector_x = (line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0))) - (line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner0 - xcorner3
		double vector_y = (line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0))) - (line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner0 - ycorner3
		
		double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		
		this.s1.setX((line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0))) - 5.0*unit_vec_x); //xcorner1
		this.s1.setY((line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0))) - 5.0*unit_vec_y); //ycorner1
		this.s1.setTheta(theta);
		
		this.s2.setX((line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0))) + 5.0*unit_vec_x); //xcorner2
		this.s2.setY((line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0))) + 5.0*unit_vec_y); //ycorner2
		this.s2.setTheta(theta);
		
		this.s1.updateBody();
		this.s2.updateBody();
	}
	
	/*Draw vehicle AND all of its components*/
	public void draw(Graphics g) {
		g.drawPolygon(this.xpoints, this.ypoints, this.num_points);

		this.w1.draw(g);
		this.w2.draw(g);
		
		this.s1.draw(g);
		this.s2.draw(g);
	}
}
