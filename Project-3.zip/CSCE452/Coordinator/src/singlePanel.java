import java.awt.*;
import java.util.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionAdapter;
import java.awt.Point;

import javax.swing.*;
import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class singlePanel extends JPanel {
	private JToggleButton button0, button1;
	private JButton button2, button3, button4, button5, button6, button7, button8, button9, button10, button11;
	private JTextField text0, text1, text2, text3;
	private	JLabel label0;
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	private static final int XORIGIN = 300;
	private static final int YORIGIN = 380;

	private int xpoints_panel0[] = {800, 970, 970, 800};
	private int ypoints_panel0[] = {10, 10, 320, 320};
	private int num_points_panel0 = 4;
	
	private ArrayList lightSources;
	private ArrayList vehicles;
	private Vehicle currVehicle;
	private Point mousePoint;
	private int paint_count;
	
	private boolean addingLight = false;
	private boolean addingVehicle = false;
	private boolean crossWire = false;
	private boolean painting = false;
	private boolean init = true;
	private boolean debug = false; //testing
	
	public void updateSensors(Vehicle veh){
		//Maybe want to move this into the sensor class later
		//TODO: Update sensors of vehicle based on intensity of light sources at given angles
		
		double sIn1 = 0.0;
		double sIn2 = 0.0;
		
		for(int i = 0; i < lightSources.size(); i++){
			/*Picking based on distance to light source*/
				sIn1 += ((LightSource) lightSources.get(i)).intensityRelativeTo(veh.s1.sensor_x(), veh.s1.sensor_y());
				sIn2 += ((LightSource) lightSources.get(i)).intensityRelativeTo(veh.s2.sensor_x(), veh.s2.sensor_y());
		}
		
		veh.s1.setSensorIn(sIn1);
		veh.s2.setSensorIn(sIn2);
	}
	
	public void updateWheelspeeds(Vehicle veh){
		//TODO: Update wheelspeeds of vehicle based on sensor data and a 2x2 square matrix, k
		int[][] matrixK = veh.k();
		
		if(veh.s1.sensorIn() != 0.0 && veh.s2.sensorIn() != 0.0){
			double newSpeed1 = veh.s1.sensorIn()*matrixK[0][0] + veh.s2.sensorIn()*matrixK[0][1];
			double newSpeed2 = veh.s1.sensorIn()*matrixK[1][0] + veh.s2.sensorIn()*matrixK[1][1];
			
			if (debug) System.out.println("NewSpeed1: " + newSpeed1 + "\n");
			if (debug) System.out.println("NewSpeed2: " + newSpeed2 + "\n");
			
			if(crossWire){
				veh.w2.setSpeed(newSpeed1);
				veh.w1.setSpeed(newSpeed2);
			}
			else{
				veh.w1.setSpeed(newSpeed1);
				veh.w2.setSpeed(newSpeed2);
			}
		}
	}
	
	public void updateVehicle(Vehicle veh){
		double[] xNorm = new double[2];			//this will be our normalized x vector determined by the sum of w1 and w2
		double xTheta;							//this will be the normalized theta associated with xNorm in degrees
		
		if (veh.w1.speed() == 0 && veh.w2.speed() == 0){
			return;
		}
		
		updateSensors(veh);
		updateWheelspeeds(veh);
		
		xNorm[0] = (veh.w1.speed() * Math.sin(-Math.PI / 4.0)) + (veh.w2.speed() * Math.sin(Math.PI / 4.0));
		xNorm[1] = (veh.w1.speed() * Math.cos(-Math.PI / 4.0)) + (veh.w2.speed() * Math.cos(Math.PI / 4.0));
		
		xTheta = Math.atan2(xNorm[1], xNorm[0]) / RADIAN_CONV - 90;
		if (debug) System.out.println("vehicleTheta: " + veh.theta() + "\nxTheta: " + xTheta);
		if (debug) System.out.println("XChange: " + Math.cos(veh.theta()*RADIAN_CONV) + "\nYChange: " + Math.sin(veh.theta()*RADIAN_CONV) + "\n");
		
		veh.setTheta((veh.theta() - xTheta)); // minus because reversed quadrants
		veh.setX(veh.x() + Math.cos(veh.theta() * RADIAN_CONV));
		veh.setY(veh.y() - Math.sin(veh.theta() * RADIAN_CONV));
	}
	
	public Color paint_switch(int x) {
		switch(x)
		{
			case 1: return Color.RED;
			case 2: return Color.ORANGE;
			case 3: return Color.YELLOW;
			case 4: return Color.GREEN;
			case 5: return Color.BLUE;
			case 6: return Color.MAGENTA;
			default: return Color.BLACK;
		}
	}
	
	public void paint_controller(){
		if(painting){
			painting = false;
		}
		else{
			painting = true;
		}
	}
	
	public void lightController() {
		addingVehicle = false;
		if(addingLight){
			addingLight = false;
		}
		else{
			addingLight = true;
		}
	}
	
	public void vehicleController() {
		addingLight = false;
		if(addingVehicle){
			addingVehicle = false;
		}
		else{
			addingVehicle = true;
		}
	}
	

	public void update() {	//called implicitly to handle mouse events
		if (button0 == null) 
			return;
		try{
			if (button0.isSelected()) {
				for(int j = 0; j < vehicles.size(); j++){
					Vehicle tempVehicle = (Vehicle)vehicles.get(j);
					updateVehicle(tempVehicle);
					tempVehicle.updateBody();
					repaint();
				}
			}
			if (button1.isSelected()) {
				/*Button will do the same, but just adding paint for lols*/
				if (paint_count == 6){
					paint_count = 0;
				}
				else{
					paint_count = paint_count + 1;
				}
				paint_switch(paint_count);
				
				for(int j = 0; j < vehicles.size(); j++){
					Vehicle tempVehicle = (Vehicle)vehicles.get(j);
					updateVehicle(tempVehicle);
					tempVehicle.updateBody();
					repaint();
				}
			}
		}catch(Exception e){
			System.out.println("Error...\n");
		}
	}

	public singlePanel()
	{
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e){
			e.printStackTrace();
		}
		
		if(init){	//initialization mini-function
			init = false;
			
			addMouseListener(new MouseListener() {
					@Override
					public void mouseClicked(MouseEvent e){
						if(addingLight){
							/*Making Light Sources*/
							lightSources.add(new LightSource(e.getX(), e.getY()));
						}
					}
					public void mouseExited(MouseEvent e){

					}
					public void mouseEntered(MouseEvent e){

					}
					public void mousePressed(MouseEvent e){
						if(addingVehicle){
							/*Making Vehicle*/
							currVehicle = new Vehicle((double)e.getX(), (double)e.getY());
							vehicles.add(currVehicle);
							mousePoint = e.getPoint();
						}
					} 
					public void mouseReleased(MouseEvent e){

					}		
			});
			
			addMouseMotionListener(new MouseMotionAdapter() {
				@Override
				public void mouseDragged(MouseEvent e) {
					if(addingVehicle){
						int dx = e.getX() - mousePoint.x;
						int dy = e.getY() - mousePoint.y;
						//origin.setLocation(origin.x + dx, origin.y + dy);
						double theta = -1*Math.atan2((double)dy, (double)dx)/RADIAN_CONV; // atan2 ends up making it right side up but our coordinate system is reversed, java frame			
						//System.out.println(theta);
						currVehicle.setTheta(theta);
						currVehicle.updateBody();
						repaint();
					}
				}
			});
			
			lightSources = new ArrayList(0);
			vehicles = new ArrayList(0);
			repaint();
		}
		// center window on screen
		setLayout(null);
		
		label0 = new JLabel("Environment Controller");
		add(label0);
		label0.setBounds(830, 20, 120, 20);
		
		// Start Driving?
		button0 = new JToggleButton();
		button0.setText("Start");
		button0.setVisible(true);
		button0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(button0.getText() == "Start"){
					button0.setText("Stop");
				}
				else{
					button0.setText("Start");
				}
				button1.setEnabled(!button0.isSelected());
			}
		});
		add(button0);
		button0.setBounds(825, 50, 120, 20);
		
		// Something???...
		button1 = new JToggleButton();
		button1.setText("???");
		button1.setVisible(true);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				paint_controller();
				button0.setEnabled(!button1.isSelected());
			}
		});
		add(button1);
		button1.setBounds(825, 70, 120, 20);
		
		// Add Vehicles
		button2 = new JButton();
		button2.setText("Add Light Source");
		button2.setVisible(true);
		button2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				lightController();
			}
		});
		add(button2);
		button2.setBounds(825, 90, 120, 20);
		
		// Clear Vehicles
		button3 = new JButton();
		button3.setText("Clear Lights");
		button3.setVisible(true);
		button3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{	
				lightSources.clear();
				addingLight = false;
				repaint();
			}
		});
		add(button3);
		button3.setBounds(825, 110, 120, 20);
		
		// Add Light Sources
		button4 = new JButton();
		button4.setText("Add Vehicle");
		button4.setVisible(true);
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				vehicleController();
			}
		});
		add(button4);
		button4.setBounds(825, 130, 120, 20);
		
		// Clear Light Sources
		button5 = new JButton();
		button5.setText("Clear Vehicles");
		button5.setVisible(true);
		button5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				vehicles.clear();
				addingVehicle = false;
				repaint();
			}
		});
		add(button5);
		button5.setBounds(825, 150, 120, 20);
		
		// Change K matrix
		button6 = new JButton();
		button6.setText("Set K Matrix");
		button6.setVisible(true);
		button6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				String s0, s1, s2, s3;
				s0 = text0.getText();
				s1 = text1.getText();
				s2 = text2.getText();
				s3 = text3.getText();
				
				try{
					int k00, k01, k10, k11;
					k00 = Integer.parseInt(s0);
					k01 = Integer.parseInt(s1);
					k10 = Integer.parseInt(s2);
					k11 = Integer.parseInt(s3);
					
					int[][] matrix_k = new int[][]{ {k00, k01}, {k10, k11} };
					currVehicle.setK(matrix_k);
				}
				catch(Exception ex){
					
				}
			}
		});
		add(button6);
		button6.setBounds(825, 170, 120, 20);

		text0 = new JTextField();
		add(text0);
		text0.setBounds(830, 200, 50, 20);
		
		text1 = new JTextField();
		add(text1);
		text1.setBounds(890, 200, 50, 20);
		
		text2 = new JTextField();
		add(text2);
		text2.setBounds(830, 230, 50, 20);
		
		text3 = new JTextField();
		add(text3);
		text3.setBounds(890, 230, 50, 20);
		
		// Change K matrix
		button7 = new JButton();
		button7.setText("Set K Matrix (ALL)");
		button7.setVisible(true);
		button7.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				String s0, s1, s2, s3;
				s0 = text0.getText();
				s1 = text1.getText();
				s2 = text2.getText();
				s3 = text3.getText();
				try{
					int k00, k01, k10, k11;
					k00 = Integer.parseInt(s0);
					k01 = Integer.parseInt(s1);
					k10 = Integer.parseInt(s2);
					k11 = Integer.parseInt(s3);
					
					int[][] matrix_k = new int[][]{ {k00, k01}, {k10, k11} };
					
					for (int i = 0; i < vehicles.size(); i++){
						((Vehicle) vehicles.get(i)).setK(matrix_k);
					}	
				}
				catch(Exception ex){
					
				}
			}
		});
		add(button7);
		button7.setBounds(825, 260, 120, 20);
		
		if (debug){
			button8 = new JButton();
			button8.setText("W1_Speed++");
			button8.setVisible(true);
			button8.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e)
				{
					currVehicle.w1.setSpeed(currVehicle.w1.speed() + 1);
					System.out.println(currVehicle.w1.speed());
				}
			});
			add(button8);
			button8.setBounds(825, 360, 120, 20);
			
			
			button9 = new JButton();
			button9.setText("W2_Speed++");
			button9.setVisible(true);
			button9.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e)
				{
					currVehicle.w2.setSpeed(currVehicle.w2.speed() + 1);
					System.out.println(currVehicle.w2.speed());
				}
			});
			add(button9);
			button9.setBounds(825, 380, 120, 20);
			
			
			button10 = new JButton();
			button10.setText("One Step");
			button10.setVisible(true);
			button10.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e)
				{
					for(int j = 0; j < vehicles.size(); j++){
						Vehicle tempVehicle = (Vehicle)vehicles.get(j);
						updateVehicle(tempVehicle);
						tempVehicle.updateBody();
						repaint();
					}
				}
			});
			add(button10);
			button10.setBounds(825, 400, 120, 20);
			
			
		}
		
		//flip wheel directions
		button11 = new JButton();
		button11.setText("Flip Behavior");
		button11.setVisible(true);
		button11.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				crossWire = crossWire ? false : true;
			}
		});
		add(button11);
		button11.setBounds(825,280,120,20);
			
			
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		
		g.drawPolygon(xpoints_panel0, ypoints_panel0, num_points_panel0);

		for(int i = 0; i < lightSources.size(); i++){
			g.drawImage(((LightSource) lightSources.get(i)).img(), ((LightSource) lightSources.get(i)).x()-((LightSource) lightSources.get(i)).imgW()/2, ((LightSource) lightSources.get(i)).y()-((LightSource) lightSources.get(i)).imgH()/2, null);
		}

		if(painting){
			g.setColor(paint_switch(paint_count));
		}
		
		for(int j = 0; j < vehicles.size(); j++){
			((Vehicle) vehicles.get(j)).draw(g);
		}
	}
}
