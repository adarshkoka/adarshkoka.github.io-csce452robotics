import java.awt.*;
import javax.swing.*;
import java.awt.image.*;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;

public class Sensor { 
    private double x;    // x-coordinate
    private double y;    // y-coordinate
	private double theta; // angle of vehicle
	private double sensorIn; // sensor inputs to be updated by light intensity

	private static final double RADIAN_CONV = (Math.PI / 180.0);
		
	private int stem_x0, stem_y0, stem_x1, stem_y1; 	
	private int sensorWidth, sensorHeight; 
		
	private double sensor_x0, sensor_x1;
	private double sensor_y0, sensor_y1;
	private GeneralPath path = new GeneralPath();
	
    // point initialized from parameters
    public Sensor(double xorg, double yorg) {
		this.theta = 90.0;
		this.x = xorg;
		this.y = yorg;
		this.sensorWidth = 7;
		this.sensorHeight = 7;
		this.sensorIn = 1.0;
		
		double d = 10.0; 
		
		/*Making Sensor stem*/
		stem_x0 = (int) xorg;
		stem_y0 = (int) yorg;
		stem_x1 = (int)(xorg + d*Math.cos(RADIAN_CONV*theta));
		stem_y1 = (int)(yorg - d*Math.sin(RADIAN_CONV*theta));
		
		/*Making Sensor eye*/
		/*First need to find top left corner of drawArc function*/
		double vector_x = (xorg + d*Math.cos(RADIAN_CONV*theta)) - xorg;
		double vector_y = (yorg - d*Math.sin(RADIAN_CONV*theta)) - yorg;
		
		double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));

		/*Distance from a point is x,y -/+ du*/
		double new_point_x = (xorg + d*Math.cos(RADIAN_CONV*theta)) + sensorHeight*unit_vec_x; //distance is stemx1 + unitvec
		double new_point_y = (yorg - d*Math.sin(RADIAN_CONV*theta)) + sensorHeight*unit_vec_y; //distance is stemy1 + unitvec

		double m = ((yorg - d*Math.sin(RADIAN_CONV*theta))-yorg)/((xorg + d*Math.cos(RADIAN_CONV*theta))-xorg); //stemy1-stemy0/stemx1-stemx0
		double m_reciprocal, b_perp, tmp_point_x, tmp_point_y;
		if(m == 0.0){
			tmp_point_x = new_point_x + 10.0*Math.cos(RADIAN_CONV*90.0);
			tmp_point_y = new_point_y - 10.0*Math.sin(RADIAN_CONV*90.0);
		}
		else{
			m_reciprocal = -1/m;
			
			b_perp = new_point_y - m_reciprocal * new_point_x;
			//Perpendicular line
			tmp_point_x = 0;
			tmp_point_y = m_reciprocal*tmp_point_x + b_perp;
		}
		
		double perp_vector_x = new_point_x - tmp_point_x;
		double perp_vector_y = new_point_y - tmp_point_y;
		
		double perp_unit_vec_x = perp_vector_x / (Math.sqrt(perp_vector_x*perp_vector_x + perp_vector_y*perp_vector_y));
		double perp_unit_vec_y = perp_vector_y / (Math.sqrt(perp_vector_x*perp_vector_x + perp_vector_y*perp_vector_y));

		sensor_x0 = new_point_x - (double)(sensorWidth/2)*perp_unit_vec_x;
		sensor_y0 = new_point_y - (double)(sensorHeight/2)*perp_unit_vec_y;
		
		sensor_x1 = new_point_x + (double)(sensorWidth/2)*perp_unit_vec_x;
		sensor_y1 = new_point_y + (double)(sensorHeight/2)*perp_unit_vec_y;
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setTheta(double theta) { this.theta = theta; }
	public void setSensorIn(double sensorIn) { this.sensorIn = sensorIn; }
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public double theta() { return theta; }
	public double sensorIn() { return sensorIn; }
	
	public int sensor_x() { return stem_x1; } // Access the beginning point of the sensors
	public int sensor_y() { return stem_y1; }
	
	
	// class functions
	public void updateBody(){
		double d = 10.0; 
		
		/*Making Sensor stem*/
		stem_x0 = (int) x;
		stem_y0 = (int) y;
		stem_x1 = (int)(x + d*Math.cos(RADIAN_CONV*theta));
		stem_y1 = (int)(y - d*Math.sin(RADIAN_CONV*theta));
		
		/*Making Sensor eye*/
		/*First need to find top left corner of drawArc function*/
		double vector_x = (x + d*Math.cos(RADIAN_CONV*theta)) - x;
		double vector_y = (y - d*Math.sin(RADIAN_CONV*theta)) - y;
		
		double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));

		/*Distance from a point is x,y -/+ du*/
		double new_point_x = (x + d*Math.cos(RADIAN_CONV*theta)) + (double)sensorHeight*unit_vec_x; //distance is stemx1 + unitvec
		double new_point_y = (y - d*Math.sin(RADIAN_CONV*theta)) + (double)sensorHeight*unit_vec_y; //distance is stemy1 + unitvec
		
		double m = ((y - d*Math.sin(RADIAN_CONV*theta))-y)/((x + d*Math.cos(RADIAN_CONV*theta))-x); //stemy1-stemy0/stemx1-stemx0
		double m_reciprocal, b_perp, tmp_point_x, tmp_point_y;
		if(m == 0.0){
			tmp_point_x = new_point_x + 10.0*Math.cos(RADIAN_CONV*90.0);
			tmp_point_y = new_point_y - 10.0*Math.sin(RADIAN_CONV*90.0);
		}
		else{
			m_reciprocal = -1/m;
			
			b_perp = new_point_y - m_reciprocal * new_point_x;
			//Perpendicular line
			tmp_point_x = 0;
			tmp_point_y = m_reciprocal*tmp_point_x + b_perp;
		}
		
		double perp_vector_x = new_point_x - tmp_point_x;
		double perp_vector_y = new_point_y - tmp_point_y;
		
		double perp_unit_vec_x = perp_vector_x / (Math.sqrt(perp_vector_x*perp_vector_x + perp_vector_y*perp_vector_y));
		double perp_unit_vec_y = perp_vector_y / (Math.sqrt(perp_vector_x*perp_vector_x + perp_vector_y*perp_vector_y));

		sensor_x0 = new_point_x - (double)(sensorWidth/2)*perp_unit_vec_x;
		sensor_y0 = new_point_y - (double)(sensorHeight/2)*perp_unit_vec_y;

		sensor_x1 = new_point_x + (double)(sensorWidth/2)*perp_unit_vec_x;
		sensor_y1 = new_point_y + (double)(sensorHeight/2)*perp_unit_vec_y;
	}
	
	public void draw(Graphics g) {
		g.drawLine(stem_x0, stem_y0, stem_x1, stem_y1);
		//g.drawArc(sensor_x0, sensor_y0, sensorWidth, sensorHeight, (int)(-180.0-(theta*Math.cos(RADIAN_CONV*theta))), (int)(180.0-(theta*Math.cos(RADIAN_CONV*theta))));
		path.reset();
		path.moveTo(sensor_x0, sensor_y0);
		path.lineTo(stem_x1, stem_y1);
		path.lineTo(sensor_x1, sensor_y1);
		
		Graphics2D g2d = (Graphics2D) g;
		g2d.draw(path);
	}
}
