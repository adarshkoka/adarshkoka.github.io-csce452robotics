import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

import java.lang.Math.*;

public class LightSource { 
    private int x;    // x-coordinate
    private int y;    // y-coordinate
	private Image lightSourceImage;	// Light Source
	private int imgW; // Width of img
	private int imgH; // Height of img

    // point initialized from parameters
    public LightSource(int x, int y) {
        this.x = x;
        this.y = y;
		this.imgW = 80;
		this.imgH = 60;
					
		try{
			this.lightSourceImage = ImageIO.read(new File("lightSource.jpg")); // Change this to users dir
			this.lightSourceImage = lightSourceImage.getScaledInstance(this.imgW, this.imgH, Image.SCALE_DEFAULT);
		} catch (Throwable IOException){
			System.out.println("The image file isn't there!\n");
		}
    }
	
	//mutator methods
	public void setX(int x){ this.x = x; }
	public void setY(int y){ this.y = y; }
	
    // accessor methods
    public int x() { return x; }
    public int y() { return y; }
	public Image img() { return lightSourceImage; }
	public int imgW() { return imgW; }
	public int imgH() { return imgH; }
	
	// class functions
	public double distanceFrom(double x, double y) {
		//return Math.sqrt((x-(double)this.x)*(x-(double)this.x) + (y-(double)this.y)*(y-(double)this.y)); // Cast point to double when finding dist; keep precision
		return (x-(double)this.x)*(x-(double)this.x) + (y-(double)this.y)*(y-(double)this.y); // d^2
	}
	
	public double intensityRelativeTo(int x, int y) {
		double intensity = 100.0 * 1.0/distanceFrom((double)x, (double)y); // Inverse squared function, max intensity = 100.0
		
		return intensity;
	}
}
