import java.awt.*;
import java.util.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;
import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class singlePanel extends JPanel {
	private static final double RADIAN_CONV = (Math.PI / 180);
	private static final int XORIGIN = 250;
	private static final int YORIGIN = 380;
	
	// Link Length of arm 0 (AND ALL ARMS) 
	private static final int A0 = 100;
	
	private double 	theta0 = 90,
					theta1 = 90,
					theta2 = 90;
					
	private int 	xEnd_a0 = XORIGIN,
					yEnd_a0 = YORIGIN,
					xEnd_a1	= XORIGIN,
					yEnd_a1	= YORIGIN,
					xEnd_a2	= XORIGIN,
					yEnd_a2 = YORIGIN;
	
	private boolean	painting = false;
	private ArrayList points;
	private int rad = 10, i;
	
	private boolean init = true;
	
	public void paint_controller(){
		if(painting){
			painting = false;
		}
		else{
			painting = true;
		}
	}
	
	public Color paint_switch(int x) {
		switch(x)
		{
			case 1: return Color.BLUE;
			case 2: return Color.CYAN;
			case 3: return Color.ORANGE;
			case 4: return Color.GREEN;
			case 5: return Color.YELLOW;
			default: return Color.RED;
		}
	}
					
	public void updateEnds(int jointIndex, double theta, int xStart, int yStart, int xEnd, int yEnd ){
		double rad_angle = theta*RADIAN_CONV;
		xEnd = ((int)(A0 * Math.cos(rad_angle))) + xStart;
		yEnd = (-(int)(A0 * Math.sin(rad_angle))) + yStart;
		switch(jointIndex){
			case 0: 
				xEnd_a0 = xEnd-50;
				yEnd_a0 = yEnd-50;
				break;
				
			case 1:
				xEnd_a1 = xEnd-20;
				yEnd_a1 = yEnd-20;
				break;
				
			case 2: 
				xEnd_a2 = xEnd+10;
				yEnd_a2 = yEnd+10;
				break;
		}
	}
	
	public singlePanel()
	{
		if(init){	//initialization mini-function
			init = false;
			updateEnds(0, theta0, XORIGIN, YORIGIN, xEnd_a0, yEnd_a0);
			updateEnds(1, theta1, xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);
			updateEnds(2, theta2, xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
			points = new ArrayList(0);
			repaint();
			
		}
		// center window on screen
		setLayout(null);
		
		// Joint 1 Counter-Clockwise button
		JButton button0 = new JButton();
		button0.setText("Joint 1 CCW");
		button0.setVisible(true);
		button0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				// change line1 here...
				theta0 = theta0 + 1;
				// need to make function for following:
				updateEnds(0,theta0, XORIGIN, YORIGIN, xEnd_a0, yEnd_a0);
				
				// update line2 (but dont change theta1
				//xStart_a1 = xEnd_a0;
				//yStart_a1 = yEnd_a0;
				updateEnds(1, theta1, xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);
				updateEnds(2, theta2, xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
				
				repaint();
			}
		});
		add(button0);
		button0.setBounds(450, 10, 120, 20);
		
		// Joint 1 Clockwise
		JButton button1 = new JButton();
		button1.setText("Joint 1 CW");
		button1.setVisible(true);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				// change line1 here...
				theta0 = theta0 - 1;
				
				updateEnds(0,theta0, XORIGIN, YORIGIN, xEnd_a0, yEnd_a0);
				
				// update line2 (but dont change theta1
				//xStart_a1 = xEnd_a0;
				//yStart_a1 = yEnd_a0;
				updateEnds(1, theta1, xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);
				updateEnds(2, theta2, xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
				
				repaint();
			}
		});
		add(button1);
		button1.setBounds(450, 30, 120, 20);
		
		// Joint 2 Counter-Clockwise button
		JButton button2 = new JButton();
		button2.setText("Joint 2 CCW");
		button2.setVisible(true);
		button2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				theta1 = theta1 + 1;
				updateEnds(1, theta1, xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);
				updateEnds(2, theta2, xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
				repaint();
			}
		});
		add(button2);
		button2.setBounds(450, 50, 120, 20);
		
		// Joint 2 Clockwise button
		JButton button3 = new JButton();
		button3.setText("Joint 2 CW");
		button3.setVisible(true);
		button3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				theta1 = theta1 - 1;
				updateEnds(1, theta1, xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);
				updateEnds(2, theta2, xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
				repaint();
			}
		});
		add(button3);
		button3.setBounds(450, 70, 120, 20);
		
		
		// Joint 3 Counter-Clockwise button
		JButton button4 = new JButton();
		button4.setText("Joint 3 CCW");
		button4.setVisible(true);
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				theta2 = theta2 + 1;
				updateEnds(2, theta2, xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
				repaint();
			}
		});
		add(button4);
		button4.setBounds(450, 90, 120, 20);
		
		// Joint 3 Clockwise button
		JButton button5 = new JButton();
		button5.setText("Joint 3 CW");
		button5.setVisible(true);
		button5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				theta2 = theta2 - 1;
				updateEnds(2, theta2, xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
				repaint();
			}
		});
		add(button5);
		button5.setBounds(450, 110, 120, 20);		
				
		// Turn on/off painting functionality
		JButton button6 = new JButton();
		button6.setText("Paint");
		button6.setVisible(true);
		button6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				paint_controller();
				repaint();
			}
		});
		add(button6);
		button6.setBounds(450, 130, 120, 20);			
				//Change color of paint
		JButton button7 = new JButton();
		
		button7.setVisible(true);
		button7.setText("RED");
		button7.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{	
				if (i == 5){
					i = 0;
				}
				else{
					i = i + 1;
				}
				if (i == 0){
					button7.setText("RED");
				} else if (i == 1){
					button7.setText("BLUE");
				} else if (i == 2) {
					button7.setText("CYAN");
				} else if (i == 3) {
					button7.setText("ORANGE");
				} else if (i == 4) {
					button7.setText("GREEN");
				} else if (i == 5) {
					button7.setText("YELLOW");
				}
				paint_switch(i);
			}
		});
		add(button7);
		button7.setBounds(450, 150, 120, 20);
	
		// Clear the window of old paint
		JButton button8 = new JButton();
		button8.setText("Erase");
		button8.setVisible(true);
		button8.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				points.clear();
				painting = false;
				repaint();
			}
		});
		add(button8);
		button8.setBounds(450, 170, 120, 20);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		
		g.drawRoundRect(200, 335, 80, 50, 50, 50); // Base link shape
		
		/*Use this to display integers to console*/
		//String s = String.valueOf(xEnd_a0);
		//System.out.write(s.getBytes(), 0, s.getBytes().length);
		//System.out.write('\n');
		
		g.drawLine(XORIGIN, YORIGIN, xEnd_a0, yEnd_a0);
		
		g.drawLine(xEnd_a0, yEnd_a0, xEnd_a1, yEnd_a1);	
		
		g.drawLine(xEnd_a1, yEnd_a1, xEnd_a2, yEnd_a2);
		
		/*Making first link*/
		
		if(painting){
			points.add(new Point(xEnd_a2, yEnd_a2, paint_switch(i)));
		}

		for(int i = 0; i < points.size(); i++){
			g.setColor(((Point) points.get(i)).color());
			g.fillOval(((Point) points.get(i)).x()- rad/2, ((Point) points.get(i)).y() - rad/2, rad, rad);
		}		
	}
}
