import java.awt.*;
import javax.swing.*;

public class Point { 
    private int x;    // x-coordinate
    private int y;    // y-coordinate
	private Color c;  // Color component
	/*vehicle and wheel components*/
	private double theta;
	private double alphaR;
	private double alphaL;
	private double speed;
	
    // point initialized from parameters
    public Point(int x, int y, Color c, double theta, double alphaR, double alphaL, double speed) {
        this.x = x;
        this.y = y;
		this.c = c;
		// this.count = count;
		this.theta = theta;
		this.alphaR = alphaR;
		this.alphaL = alphaL;
		this.speed = speed;
    }
	
	//mutator methods
	public void setX(int x){ this.x = x; }
	public void setY(int y){ this.y = y; }
	public void setC(Color c){ this.c = c; }
	// public void setCount() { this.count = count; }
	public void setTheta() { this.theta = theta; }
	public void setAlphaR() { this.alphaR = alphaR; }
	public void setAlphaL() { this.alphaL = alphaL; }
	public void setSpeed() { this.speed = speed; }
	
    // accessor methods
    public int x() { return x; }
    public int y() { return y; }
    public Color color() { return c;}
	// public double count() { return count; }
	public double theta() { return theta; }
	public double alphaR() { return alphaR; }
	public double alphaL() { return alphaL; }
	public double speed() { return speed; }
	
}
