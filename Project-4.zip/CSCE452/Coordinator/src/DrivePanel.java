import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class DrivePanel { 

    private double x;    // x-coordinate origin
    private double y;    // y-coordinate origin
	private boolean drivingVehicle;
	private boolean drawCar;
	private boolean replaying = false;
	Vehicle vehicle;
	
	BufferedImage scaled;
	AffineTransform at;
	AffineTransformOp scaleOp;
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	
	private Image vImg;	// Driver Body
	private int vImgX;
	private int vImgY;
	private int vImgW;
	private int vImgH;
	
	private BufferedImage trackImg;	// Driver Body
	private static final int trackImgX = 810;  // origin of track image on panel
	private static final int trackImgY = 180;
	private int trackImgW;
	private int trackImgH;
	
    // point initialized from parameters
    public DrivePanel(double xorg, double yorg) {
		this.drivingVehicle = false;
		this.drawCar = true;
		
		this.scaled = new BufferedImage(280, 320, BufferedImage.TYPE_INT_ARGB);
		this.at = new AffineTransform();
		this.at.scale(6, 4);
		this.scaleOp = new AffineTransformOp(this.at, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
		
		vehicle = new Vehicle(xorg, yorg);
		
		/*Vehicle body init materials*/
		double vector_x = vehicle.wFL.x() - vehicle.wFR.x();
		double vector_y = vehicle.wFL.y() - vehicle.wFR.y();
		
		double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
		double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));

		/*Distance from a point is x,y -/+ du*/
		double new_point_x_tmp = vehicle.wFL.x() + 110.0*unit_vec_x;
		double new_point_y_tmp = vehicle.wFL.y() - 110.0*unit_vec_y;
		
		double vector_x1 = vehicle.wFL.x() - vehicle.wBL.x();
		double vector_y1 = vehicle.wFL.y() - vehicle.wBL.y();
		
		double unit_vec_x1 = vector_x1 / (Math.sqrt(vector_x1*vector_x1 + vector_y1*vector_y1));
		double unit_vec_y1 = vector_y1 / (Math.sqrt(vector_x1*vector_x1 + vector_y1*vector_y1));
		
		double new_point_x = new_point_x_tmp - 13.0*unit_vec_x1;
		double new_point_y = new_point_y_tmp + 13.0*unit_vec_y1;
		
		this.vImgX = (int) (new_point_x + 17.0*Math.cos(RADIAN_CONV*vehicle.theta()) - 10.0*Math.cos(RADIAN_CONV*vehicle.theta()));
		this.vImgY = (int) (new_point_y - 17.0*Math.sin(RADIAN_CONV*vehicle.theta()) + 10.0*Math.sin(RADIAN_CONV*vehicle.theta()));
		this.vImgW = 86;
		this.vImgH = 160; 
		
		try{
			if(replaying){
				this.vImg = ImageIO.read(new File("WhiteCar.png")); // Change this to users dir
			}
			else{
				this.vImg = ImageIO.read(new File("BlueCar.png")); // Change this to users dir
			}
			this.vImg = vImg.getScaledInstance(this.vImgW, this.vImgH, Image.SCALE_DEFAULT);
		} catch (Throwable IOException){
			System.out.println("The image file isn't there!\n");
		}
		
		/*Removing white background*/
		ImageFilter filter = new RGBImageFilter() {
			int transparentColor = Color.white.getRGB() | 0xFF000000;

			public final int filterRGB(int x, int y, int rgb) {
				if ((rgb | 0xFF000000) == transparentColor) {
					return 0x00FFFFFF & rgb;
				} 
				else {
					return rgb;
				}
			}
		};
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setDrivingVehicle(boolean drivingVehicle){ this.drivingVehicle = drivingVehicle; }
	public void setDrawCar(boolean drawCar){ this.drawCar = drawCar; }
	public void isReplaying(boolean replaying){ this.replaying = replaying; }
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public boolean drivingVehicle() { return drivingVehicle; }
	public boolean drawCar() { return drawCar; }
	public boolean replaying() { return replaying; }

	public void driveController() {
		if(drivingVehicle){
			drivingVehicle = false;
		}
		else{
			drivingVehicle = true;
		}
	}	
	
	public void drawCarController() {
		if(drawCar){
			drawCar = false;
		}
		else{
			drawCar = true;
		}
	}
	
	// CSL zoom function used for track image
	public BufferedImage scale(BufferedImage orig, double x_scale, double y_scale) {
		// this.at = new AffineTransform();
		// this.at.scale(x_scale, y_scale);
		this.scaled = this.scaleOp.filter(orig, this.scaled);
		
		return this.scaled;
	}
	
	// CSL updating track image when car moves
	public void updateTrackImg(int x_pos, int y_pos ) {
		try{
			this.trackImg = ImageIO.read(new File("CMS3_border.png")); // Change this to users dir
			this.trackImg = scale(this.trackImg.getSubimage( (x_pos+600), (y_pos+495), 280, 320), 6, 4);
			//this.trackImg = scale(this.trackImg,4,4);
			//this.trackImg.getRGB( (x_pos-20), (y_pos-20), 70, 80, rgbArray, 0, 80);
			//newIm.setRGB( (x_pos-20), (y_pos-20), 140,160, rgbArray, 0, 80);
			//this.trackImg = newIm;
		} catch (Throwable IOException){
			System.out.println("The image file isn't there!\n");
		}
		return;
	}
	
	public void update(){
		vehicle.updateBody();
		/*update track image in drivepanel*/
	}
		
	/*Draw vehicle AND all of its components*/
	public void draw(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		if(drivingVehicle){
			/*track blow up*/
			g2d.drawImage(trackImg, trackImgX, trackImgY, null);
		}
		vehicle.draw((Graphics) g2d);
		if(drivingVehicle && drawCar){ // add a demo button to remove body if its too distracting
			/*vehicle Body*/
			float opacity = 0.5f;
			g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));
			
			AffineTransform oldtrans = g2d.getTransform();
			AffineTransform trans = new AffineTransform();

			trans.rotate(Math.toRadians(90.0-vehicle.theta()), vehicle.x(), vehicle.y());
			
			g2d.setTransform(trans);
			
			try{
				if(replaying){
					vImg = ImageIO.read(new File("WhiteCar.png")); // Change this to users dir
				}
				else{
					vImg = ImageIO.read(new File("BlueCar.png")); // Change this to users dir
				}
				vImg = vImg.getScaledInstance(vImgW, vImgH, Image.SCALE_DEFAULT);
			} catch (Throwable IOException){
				System.out.println("The image file isn't there!\n");
			}
			
			/*Removing white background*/
			ImageFilter filter = new RGBImageFilter() {
				int transparentColor = Color.white.getRGB() | 0xFF000000;

				public final int filterRGB(int x, int y, int rgb) {
					if ((rgb | 0xFF000000) == transparentColor) {
						return 0x00FFFFFF & rgb;
					} 
					else {
						return rgb;
					}
				}
			};
			
			ImageProducer filteredImgProd = new FilteredImageSource(vImg.getSource(), filter);
			vImg = Toolkit.getDefaultToolkit().createImage(filteredImgProd);
			
			g2d.drawImage(vImg, vImgX, vImgY, null);

			g2d.setTransform(oldtrans);

			g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f)); // Reset drawing opacity
		}
	}
}
