import java.util.*;
import java.util.Timer;
import java.util.TimerTask;

import java.awt.*;
import javax.swing.*;
import java.lang.Math.*;

public class Clock extends TimerTask {
	private double counter = 0.0;
	private boolean clk_on = false;
	DrivePanel dp;
	TrackPanel tp;

	public Clock(DrivePanel dp, TrackPanel tp, double counter){
		this.dp = dp;
		this.tp = tp;
		this.counter = counter;
	}
	
	/*setter methods*/
	public void clkController() {
		if(clk_on){
			clk_on = false;
		}
		else{
			clk_on = true;
		}
	}
	
	/*mutator*/
	public void setCounter(double counter) { this.counter = counter; }
	
	/*accessor*/
	public String time() { return convert(round(counter, 1)); }
	public double count() { return round(counter, 1); }
	public boolean clk_on() { return clk_on; }
	
	/*class methods*/
	private static double round (double value, int precision) {
		int scale = (int) Math.pow(10, precision);
		return (double) Math.round(value * scale) / scale;
	}
	
	private String convert (double n) {
		int min = (int) (n/60.0);
		int seconds = (int) (n - min*60);
		int dec = (int) (n*10.0 - min*60*10 - seconds*10);
		
		if(min < 10 && seconds < 10){
			return "0" + min + ":0" + seconds + ":" + dec;
		}
		else if(min >= 10 && seconds < 10){
			return min + ":0" + seconds + ":" + dec;
		}
		else if(min < 10 && seconds >= 10){
			return "0" + min + ":" + seconds + ":" + dec;
		}
		else{
			return min + ":" + seconds + ":" + dec;
		}
	}
	
    public void run() {
	   counter += 0.1;
       //System.out.println("Counter: " + round(counter, 1));  
	   dp.update();
	   dp.updateTrackImg(tp.drv_x_pos(), tp.drv_y_pos());
	   tp.update();
    }
}
