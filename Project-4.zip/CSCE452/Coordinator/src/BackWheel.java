import java.awt.*;
import javax.swing.*;
import java.awt.image.*;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class BackWheel { 
    private double x;    // x-coordinate origin
    private double y;    // y-coordinate origin
	private double theta; // angle of BackWheel
	private boolean left;
	private double speed;

	private static final double RADIAN_CONV = (Math.PI / 180.0);
	
	private int xcorner0, xcorner1, xcorner2, xcorner3; //xcorner 0 = topleft, xcorner 1 = bottomleft, xcorner 2 = bottomright, xcorner 3 = topright
	private int ycorner0, ycorner1, ycorner2, ycorner3; //ycorner 0 = topleft, ycorner 1 = bottomleft, ycorner 2 = bottomright, ycorner 3 = topright
	
	private int xpoints[];
	private int ypoints[];
	private int num_points;
	
    // point initialized from parameters
    public BackWheel(double xorg, double yorg, boolean left) {
		this.theta = 180.0;
		this.x = xorg;
		this.y = yorg;
		this.left = left;
		this.speed = 1.0;
		
		double dx = 11.0;
		double dy = 11.0;
		
		if(left) { // A left BackWheel			
			/*Adding a small unit vector for larger BackWheels*/
			double vector_x = (x + dx*Math.cos(RADIAN_CONV*theta)) - (x - dx*Math.cos(RADIAN_CONV*theta)); // xcorner3 - xcorner2
			double vector_y = (y - dy*Math.sin(RADIAN_CONV*theta)) - (y + dy*Math.sin(RADIAN_CONV*theta)); // ycorner3 - ycorner2
		
			double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			/*Distance from a point is x,y -/+ du*/
			xcorner3 = (int)(x + dx*Math.cos(RADIAN_CONV*theta) + 5.0*unit_vec_x);
			ycorner3 = (int)(y - dy*Math.sin(RADIAN_CONV*theta) + 5.0*unit_vec_y);
			
			xcorner2 = (int)(x - dx*Math.cos(RADIAN_CONV*theta) - 5.0*unit_vec_x);
			ycorner2 = (int)(y + dy*Math.sin(RADIAN_CONV*theta) - 5.0*unit_vec_y);
			
			//Corners based on the bottom line segment point
			xcorner0 = (int)((x + dx*Math.cos(RADIAN_CONV*theta)) - dx*Math.cos(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_x); //subtract from xcorner3
			ycorner0 = (int)((y - dy*Math.sin(RADIAN_CONV*theta)) + dy*Math.sin(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_y); //add onto ycorner3
			
			xcorner1 = (int)((x - dx*Math.cos(RADIAN_CONV*theta)) - dx*Math.cos(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_x); //subtract from xcorner2
			ycorner1 = (int)((y + dy*Math.sin(RADIAN_CONV*theta)) + dy*Math.sin(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_y); //add onto ycorner2		
			
		}
		else{ // Else a right BackWheel
			/*Adding a small unit vector for larger BackWheels*/
			double vector_x = (x + dx*Math.cos(RADIAN_CONV*theta)) - (x - dx*Math.cos(RADIAN_CONV*theta)); // xcorner0 - xcorner1
			double vector_y = (y - dy*Math.sin(RADIAN_CONV*theta)) - (y + dy*Math.sin(RADIAN_CONV*theta)); // ycorner0 - ycorner1
		
			double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			/*Distance from a point is x,y -/+ du*/
			xcorner0 = (int)(x + dx*Math.cos(RADIAN_CONV*theta) + 5.0*unit_vec_x);
			ycorner0 = (int)(y - dy*Math.sin(RADIAN_CONV*theta) + 5.0*unit_vec_y);
			
			xcorner1 = (int)(x - dx*Math.cos(RADIAN_CONV*theta) - 5.0*unit_vec_x);
			ycorner1 = (int)(y + dy*Math.sin(RADIAN_CONV*theta) - 5.0*unit_vec_y);
			
			//Corners based on the bottom line segment point
			xcorner3 = (int)((x + dx*Math.cos(RADIAN_CONV*theta)) + dx*Math.cos(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_x); //subtract from xcorner3
			ycorner3 = (int)((y - dy*Math.sin(RADIAN_CONV*theta)) - dy*Math.sin(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_y); //add onto ycorner3
			
			xcorner2 = (int)((x - dx*Math.cos(RADIAN_CONV*theta)) + dx*Math.cos(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_x); //subtract from xcorner2
			ycorner2 = (int)((y + dy*Math.sin(RADIAN_CONV*theta)) - dy*Math.sin(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_y); //add onto ycorner2	
		}
		
		int x_points[] = {xcorner0, xcorner1, xcorner2, xcorner3};
		int y_points[] = {ycorner0, ycorner1, ycorner2, ycorner3};
		
		this.xpoints = x_points;
		this.ypoints = y_points;
		this.num_points = 4;
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setTheta(double theta) { this.theta = theta; }
	public void setSpeed(double speed) { this.speed = speed; }
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public double theta() { return theta; }
	public double speed() { return speed; }
	
	// class functions
	public void updateBody() {
		double dx = 11.0;
		double dy = 11.0;
		
		if(left) { // A left BackWheel
			/*Adding a small unit vector for larger BackWheels*/
			double vector_x = (x + dx*Math.cos(RADIAN_CONV*theta)) - (x - dx*Math.cos(RADIAN_CONV*theta)); // xcorner3 - xcorner2
			double vector_y = (y - dy*Math.sin(RADIAN_CONV*theta)) - (y + dy*Math.sin(RADIAN_CONV*theta)); // ycorner3 - ycorner2
		
			double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			/*Distance from a point is x,y -/+ du*/
			xcorner3 = (int)(x + dx*Math.cos(RADIAN_CONV*theta) + 5.0*unit_vec_x);
			ycorner3 = (int)(y - dy*Math.sin(RADIAN_CONV*theta) + 5.0*unit_vec_y);
			
			xcorner2 = (int)(x - dx*Math.cos(RADIAN_CONV*theta) - 5.0*unit_vec_x);
			ycorner2 = (int)(y + dy*Math.sin(RADIAN_CONV*theta) - 5.0*unit_vec_y);
			
			//Corners based on the bottom line segment point
			xcorner0 = (int)((x + dx*Math.cos(RADIAN_CONV*theta)) - dx*Math.cos(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_x); //subtract from xcorner3
			ycorner0 = (int)((y - dy*Math.sin(RADIAN_CONV*theta)) + dy*Math.sin(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_y); //add onto ycorner3
			
			xcorner1 = (int)((x - dx*Math.cos(RADIAN_CONV*theta)) - dx*Math.cos(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_x); //subtract from xcorner2
			ycorner1 = (int)((y + dy*Math.sin(RADIAN_CONV*theta)) + dy*Math.sin(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_y); //add onto ycorner2		
		}
		else{ // Else a right BackWheel
			/*Adding a small unit vector for larger BackWheels*/
			double vector_x = (x + dx*Math.cos(RADIAN_CONV*theta)) - (x - dx*Math.cos(RADIAN_CONV*theta)); // xcorner0 - xcorner1
			double vector_y = (y - dy*Math.sin(RADIAN_CONV*theta)) - (y + dy*Math.sin(RADIAN_CONV*theta)); // ycorner0 - ycorner1
		
			double unit_vec_x = vector_x / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			double unit_vec_y = vector_y / (Math.sqrt(vector_x*vector_x + vector_y*vector_y));
			/*Distance from a point is x,y -/+ du*/
			xcorner0 = (int)(x + dx*Math.cos(RADIAN_CONV*theta) + 5.0*unit_vec_x);
			ycorner0 = (int)(y - dy*Math.sin(RADIAN_CONV*theta) + 5.0*unit_vec_y);
			
			xcorner1 = (int)(x - dx*Math.cos(RADIAN_CONV*theta) - 5.0*unit_vec_x);
			ycorner1 = (int)(y + dy*Math.sin(RADIAN_CONV*theta) - 5.0*unit_vec_y);
			
			//Corners based on the bottom line segment point
			xcorner3 = (int)((x + dx*Math.cos(RADIAN_CONV*theta)) + dx*Math.cos(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_x); //subtract from xcorner3
			ycorner3 = (int)((y - dy*Math.sin(RADIAN_CONV*theta)) - dy*Math.sin(RADIAN_CONV*(theta-90.0)) + 5.0*unit_vec_y); //add onto ycorner3
			
			xcorner2 = (int)((x - dx*Math.cos(RADIAN_CONV*theta)) + dx*Math.cos(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_x); //subtract from xcorner2
			ycorner2 = (int)((y + dy*Math.sin(RADIAN_CONV*theta)) - dy*Math.sin(RADIAN_CONV*(theta-90.0)) - 5.0*unit_vec_y); //add onto ycorner2	
		}
		
		int x_points[] = {xcorner0, xcorner1, xcorner2, xcorner3};
		int y_points[] = {ycorner0, ycorner1, ycorner2, ycorner3};
		
		this.xpoints = x_points;
		this.ypoints = y_points;
		this.num_points = 4;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillPolygon(this.xpoints, this.ypoints, this.num_points);
	}
}
