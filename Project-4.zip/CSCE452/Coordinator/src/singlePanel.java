import java.awt.*;
import java.util.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionAdapter;
import java.util.Timer;
import java.util.TimerTask;
import java.io.File;
import java.io.FileReader;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.nio.file.Paths;
import java.io.IOException;

import javax.swing.*;
import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class singlePanel extends JPanel {
	//private JToggleButton button0, button1;
	private JButton button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11;
	private JTextField text0, text1, text2, text3;
	private	JLabel label0, label1, label2, label3, label4, label5;
					
	private int xpoints_panel[] = {810, 1090, 1090, 810};
	private int ypoints_panel[] = {500, 500, 180, 180};
	private int num_points_panel = 4;
	
	private int xpoints_panel_clk[] = {1020, 1090, 1090, 1020};
	private int ypoints_panel_clk[] = {170, 170, 150, 150};
	private int num_points_panel_clk = 4;
	
	private int xpoints_panel_btns[] = {810, 1090, 1090, 810};
	private int ypoints_panel_btns[] = {50, 50, 140, 140};
	private int num_points_panel_btns = 4;
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	private static final int XORIGIN = 300;
	private static final int YORIGIN = 380;

	ArrayList keyActions;
	Timer timer, labelTimer, replayTimer;
	Clock clk;
	private TrackPanel tp;
	private DrivePanel dp;
	private Point mousePoint;
	private int paint_count;
	private boolean init = true;
	//private boolean test = true;
	
	public class Flicker extends TimerTask {
		private float direction = -0.05f;
		float alpha = 0.00f;
		
        public void run() {
			alpha += direction;
			if (alpha < 0) {
				alpha = 0;
				direction = 0.05f;
			} else if (alpha > 1) {
				alpha = 0.95f;
				direction = -0.05f;
			}
			label0.setForeground(new Color(0, 0, 0, alpha));
        }
    }
	
	public class Replay extends TimerTask {
		int count = 1;
		double replayCounter = 0.0;
		
		// public Replay(double counter) {
			// this.replayCounter = counter;
		// }
		
		public void run(){
			String line;
			int j;
			String theta = "";
			String alphaL = "";
			String alphaR = "";
			String speed = "";
			replayCounter += 0.1;
			try (BufferedReader br = new BufferedReader(new FileReader("SaveFile.txt"))) {
					for (int i = 0; i < count; i++){
						br.readLine();
					}
					if((line = br.readLine()) != null){
						
						/*Obtain the theta, alphaR, alphaL, and speed at time t*/
						for (int i = 0; i < line.length(); i++) {
							//System.out.print(line.charAt(i));
							if(line.charAt(i) == ':'){
								if(line.charAt(i-1) == 'a'){ // theta
									j = i+2;
									while(line.charAt(j) != ' '){
										theta = theta + line.charAt(j);
										j += 1;
									}
									
								}
								else if (line.charAt(i-1) == 'R') { //alphaR
									j = i+2;
									while(line.charAt(j) != ' '){
										alphaR = alphaR + line.charAt(j);
										j += 1;
									}
								}
								else if (line.charAt(i-1) == 'L') { //alphaL
									j = i+2;
									while(line.charAt(j) != ' '){
										alphaL = alphaL + line.charAt(j);
										j += 1;
									}
								}
								else if (line.charAt(i-1) == 'd') { //speed
									j = i+2;
									while(line.charAt(j) != ' '){
										speed = speed + line.charAt(j);
										j += 1;
									}
								}
								else{
									//do nothing
								}
							}
						}
						
						// System.out.println(Double.valueOf(theta) + " ");
						// System.out.println(Double.valueOf(alphaR) + " ");
						// System.out.println(Double.valueOf(alphaL) + " ");
						//System.out.println(Double.valueOf(speed) + "\n");
						
						clk.setCounter(replayCounter);
						dp.vehicle.setTheta(Double.valueOf(theta));
						dp.vehicle.wFL.setAlpha(Double.valueOf(alphaL));
						dp.vehicle.wFR.setAlpha(Double.valueOf(alphaR));
						dp.vehicle.wFR.setSpeed(Double.valueOf(speed));
						dp.update();
						tp.update();	
						dp.updateTrackImg(tp.drv_x_pos(), tp.drv_y_pos());
							
						/*empty string containers*/
						theta = "";
						alphaL = "";
						alphaR = "";
						speed = "";
						
						count+=1;
					}
					else{
						replayTimer.cancel(); 
						replayTimer.purge(); 
						
						labelTimer.cancel();
						labelTimer.purge();
						label0.setVisible(false);
						label0.setText("PAUSED");
						
						button2.setText("Replay");
						
						labelTimer = new Timer();
						clk = new Clock(dp, tp, clk.count());
						label0.setVisible(true);
						labelTimer.schedule(new Flicker(), 0, 75);
					}
			} catch (IOException ex) {
				// Report
				System.out.println("exception");
			}	
		}
    }
	
	public void saveTrackPath(ArrayList drivePoints) {
		Writer writer = null;
		int deciseconds = 0;

		try {
			writer = new BufferedWriter(new OutputStreamWriter(
				  new FileOutputStream("SaveFile.txt"), "utf-8"));
			
			for(int i = 0; i < drivePoints.size(); i++){ //We don't need to add the first point as it is always present in drivePoints
				//writer.write(" count: " + ((Point) drivePoints.get(i)).count());
				writer.write("theta: " + ((Point) drivePoints.get(i)).theta());
				writer.write(" aR: " + ((Point) drivePoints.get(i)).alphaR());
				writer.write(" aL: " + ((Point) drivePoints.get(i)).alphaL());
				writer.write(" speed: " + ((Point) drivePoints.get(i)).speed());
				writer.write(" x: " + ((Point) drivePoints.get(i)).x());
				writer.write(" y: " + ((Point) drivePoints.get(i)).y());
				writer.write("\n");
			}
			
		} catch (IOException ex) {
			// Report
		} finally {
		   try {writer.close();} catch (Exception ex) {/*ignore*/}
		}
	}
	
	public void update() {	//called implicitly to handle mouse events
		// if (button0 == null) 
			// return;
		// try{
			// if (button0.isSelected()) {
			// }
			// if (button1.isSelected()) {
			// }
		// }catch(Exception e){
			// System.out.println("Error...\n");
		// }
	}

	public singlePanel()
	{
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e){
			e.printStackTrace();
		}
		
		if(init){	//initialization mini-function
			init = false;
 			dp = new DrivePanel(950.0, 350.0);
			tp = new TrackPanel(20, 50, dp.vehicle);
			timer = new Timer();
			labelTimer = new Timer();
			replayTimer = new Timer();
			clk = new Clock(dp, tp, 0.0);
			this.keyActions = new ArrayList(0);
			
			addKeyListener(new KeyListener() {
                    @Override
                    public void keyTyped(KeyEvent e) {
						
					}
					
                    public void keyReleased(KeyEvent e) {
						int keyCode = e.getKeyCode();
						keyActions.removeAll(Arrays.asList(keyCode));
					}
					
                    public void keyPressed(KeyEvent e) {
                        //System.out.println("Pressed " + e.getKeyChar());
						int keyCode = e.getKeyCode();
						keyActions.removeAll(Arrays.asList(keyCode)); //Lazy way to make sure there are no duplicates
						keyActions.add(keyCode);
						for(int i = 0; i < keyActions.size(); i++){
							if((int)keyActions.get(i) == 38 && dp.drivingVehicle() && clk.clk_on()){ //up
								dp.vehicle.wFR.setSpeed(dp.vehicle.wFR.speed() + 1);
								
								label1.setText("wFL speed: " + dp.vehicle.wFL.speed()); 
								label2.setText("wFR speed: " + dp.vehicle.wFR.speed());
								label3.setText("wBL speed: " + dp.vehicle.wBL.speed()); 
								label4.setText("wBR speed: " + dp.vehicle.wBR.speed());
								label5.setText("Vehicle speed: " + (dp.vehicle.wFR.speed() + dp.vehicle.wFL.speed())/2.0);
								
								//System.out.println("v0 wFR speed: " + dp.vehicle.wFR.speed());
							}
							else if((int)keyActions.get(i) == 40 && dp.drivingVehicle() && clk.clk_on()){ //down
								dp.vehicle.wFR.setSpeed(dp.vehicle.wFR.speed() - 1);
								
								label1.setText("wFL speed: " + dp.vehicle.wFL.speed()); 
								label2.setText("wFR speed: " + dp.vehicle.wFR.speed());
								label3.setText("wBL speed: " + dp.vehicle.wBL.speed()); 
								label4.setText("wBR speed: " + dp.vehicle.wBR.speed());
								label5.setText("Vehicle speed: " + (dp.vehicle.wFR.speed() + dp.vehicle.wFL.speed())/2.0);
								
								//System.out.println("v0 wFR speed: " + dp.vehicle.wFR.speed());
							}
							else if((int)keyActions.get(i) == 37 && dp.drivingVehicle() && clk.clk_on()){ //left
								dp.vehicle.wFR.setAlpha(dp.vehicle.wFR.alpha() + 1); // set alphaR
								
								label1.setText("wFL speed: " + dp.vehicle.wFL.speed()); 
								label2.setText("wFR speed: " + dp.vehicle.wFR.speed());
								label3.setText("wBL speed: " + dp.vehicle.wBL.speed()); 
								label4.setText("wBR speed: " + dp.vehicle.wBR.speed());
								label5.setText("Vehicle speed: " + (dp.vehicle.wFR.speed() + dp.vehicle.wFL.speed())/2.0);
								//System.out.println("v0 wFR alpha: " + dp.vehicle.wFR.alpha());
							}
							else if((int)keyActions.get(i) == 39 && dp.drivingVehicle() && clk.clk_on()){ //right
								dp.vehicle.wFR.setAlpha(dp.vehicle.wFR.alpha() - 1); // set alphaR
					
								label1.setText("wFL speed: " + dp.vehicle.wFL.speed()); 
								label2.setText("wFR speed: " + dp.vehicle.wFR.speed());
								label3.setText("wBL speed: " + dp.vehicle.wBL.speed()); 
								label4.setText("wBR speed: " + dp.vehicle.wBR.speed());
								label5.setText("Vehicle speed: " + (dp.vehicle.wFR.speed() + dp.vehicle.wFL.speed())/2.0);
								//System.out.println("v0 wFR alpha: " + dp.vehicle.wFR.alpha());
							}
							else if((int)keyActions.get(i) == 32){ //Start/Pause
								if(dp.replaying() || tp.replaying()){					
									replayTimer.cancel();
									replayTimer.purge();
									label0.setText("PAUSED");
									label0.setVisible(false);
									labelTimer.cancel();
									labelTimer.purge();
									dp.isReplaying(false);
									tp.isReplaying(false);
								}
								if(!dp.drivingVehicle() || !tp.painting()){ //Initial drawing
									dp.driveController();
									tp.paintController();
								}
								clk.clkController();
								if(clk.clk_on()){			
									timer.schedule(clk, 0, 100);
									button0.setText("Player 1 Pause");
									label0.setVisible(false);
									labelTimer.cancel();
									labelTimer.purge();
								}
								else{ //Pause clock/timer behavior
									timer.cancel();
									timer.purge();
									timer = new Timer();
									labelTimer = new Timer();
									clk = new Clock(dp, tp, clk.count());
									button0.setText("Player 1 Resume");
									label0.setVisible(true);
									labelTimer.schedule(new Flicker(), 0, 75);
								}
							}
							else{
								//System.out.println("Make an action for it.");
							}
							
						}
						repaint();
					}
            });
			setFocusable(true);
			
			repaint();
		}
		// center window on screen
		setLayout(null);

		label0 = new JLabel("PAUSED");
		add(label0);
		label0.setFont(new Font("TimesRoman", Font.PLAIN, 18));
		label0.setVisible(false);
		label0.setBounds(810, 150, 120, 20);

		label1 = new JLabel("wFL speed: ");
		add(label1);
		label1.setVisible(true);
		label1.setBounds(640, 520, 120, 20);
		
		label2 = new JLabel("wFR speed: ");
		add(label2);
		label2.setVisible(true);
		label2.setBounds(810, 520, 120, 20);
		
		label3 = new JLabel("wBL speed: ");
		add(label3);
		label3.setVisible(true);
		label3.setBounds(640, 540, 120, 20);
		
		label4 = new JLabel("wBR speed:");
		add(label4);
		label4.setVisible(true);
		label4.setBounds(810, 540, 120, 20);
		
		label5 = new JLabel("Vehicle speed:");
		add(label5);
		label5.setVisible(true);
		label5.setBounds(940, 520, 120, 20);
		
		//player1 drive button
		button0 = new JButton();
		button0.setText("Player 1 Start");
		button0.setVisible(true);
		button0.setFocusable(false);
		button0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(dp.replaying() || tp.replaying()){					
					replayTimer.cancel();
					replayTimer.purge();
					label0.setText("PAUSED");
					label0.setVisible(false);
					labelTimer.cancel();
					labelTimer.purge();
				}
				dp.isReplaying(false);
				tp.isReplaying(false);
				if(!dp.drivingVehicle() || !tp.painting()){ //Initial drawing
					dp.driveController();
					tp.paintController();
				}
				clk.clkController();
				if(clk.clk_on()){			
					timer.schedule(clk, 0, 100);
					button0.setText("Player 1 Pause");
					label0.setVisible(false);
					labelTimer.cancel();
					labelTimer.purge();
				}
				else{ //Pause clock/timer behavior
					timer.cancel();
					timer.purge();
					timer = new Timer();
					labelTimer = new Timer();
					clk = new Clock(dp, tp, clk.count());
					button0.setText("Player 1 Resume");
					label0.setVisible(true);
					labelTimer.schedule(new Flicker(), 0, 75);
				}
			}
		});
		add(button0);
		button0.setBounds(820, 190, 120, 20);
		
		// Save button
		button1 = new JButton();
		button1.setText("Save");
		button1.setVisible(true);
		button1.setFocusable(false);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				/*create a file containing TrackPanel points*/
				if(dp.drivingVehicle()){
					saveTrackPath(tp.drivePoints());
				}
			}
		});
		add(button1);
		button1.setBounds(960, 60, 120, 20);
		
		// Replay button
		button2 = new JButton();
		button2.setText("Replay");
		button2.setVisible(true);
		button2.setFocusable(false);
		button2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(!tp.replaying() && !dp.replaying()){
					/*initiate timer and time task to play out the game*/
					dp = new DrivePanel(950.0, 350.0);
					tp = new TrackPanel(20, 50, dp.vehicle);
					dp.isReplaying(true);
					tp.isReplaying(true);			
					dp.driveController();
					tp.paintController();
					
					timer.cancel();
					timer.purge();
					labelTimer.cancel();
					labelTimer.purge();
					label0.setVisible(false);
					labelTimer = new Timer();
					label0.setText("REPLAY");
					label0.setVisible(true);
					labelTimer.schedule(new Flicker(), 0, 75);
					replayTimer = new Timer();
					replayTimer.schedule(new Replay(), 0, 100);
					
					//button2.setText("Pause Replay");
				}
				else{
					// replayTimer.cancel(); 
					// replayTimer.purge(); 
					
					// labelTimer.cancel();
					// labelTimer.purge();
					// label0.setVisible(false);
					// label0.setText("PAUSED");
					
					// button2.setText("Resume Replay");
					
					// labelTimer = new Timer();
					// clk = new Clock(dp, tp, clk.count());
					// label0.setVisible(true);
					// labelTimer.schedule(new Flicker(), 0, 75);
				}
			}
		});
		add(button2);
		button2.setBounds(960, 85, 120, 20);
		
		// Restart button
		button3 = new JButton();
		button3.setText("Restart");
		button3.setVisible(true);
		button3.setFocusable(false);
		button3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				replayTimer.cancel();
				replayTimer.purge();
				dp = new DrivePanel(950.0, 350.0);
				tp = new TrackPanel(20, 50, dp.vehicle);
				timer.cancel();
				timer.purge();
				button0.setText("Player 1 Start");
				label1.setText("wFL speed: ");
				label2.setText("wBL speed: ");
				label3.setText("wFR speed: ");
				label4.setText("wBR speed: ");
				label5.setText("vehicle speed: ");
				label0.setVisible(false);
				labelTimer.cancel();
				labelTimer.purge();
				timer = new Timer();
				clk = new Clock(dp, tp, 0.0);
			}
		});
		add(button3);
		button3.setBounds(820, 60, 120, 20);
			
		// FR speed +
		button4 = new JButton();
		button4.setText("FR speed +");
		button4.setVisible(true);
		button4.setFocusable(false);
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(dp.drivingVehicle() && clk.clk_on()){
					dp.vehicle.wFR.setSpeed(dp.vehicle.wFR.speed() + 1);
					System.out.println("v0 wFR speed: " + dp.vehicle.wFR.speed());
					
					label1.setText("wFL speed: " + dp.vehicle.wFL.speed()); 
								label2.setText("wFR speed: " + dp.vehicle.wFR.speed());
								label3.setText("wBL speed: " + dp.vehicle.wBL.speed()); 
								label4.setText("wBR speed: " + dp.vehicle.wBR.speed());
								label5.setText("Vehicle speed: " + (dp.vehicle.wFR.speed() + dp.vehicle.wFL.speed())/2.0);
				}
			}
		});
		add(button4);
		button4.setBounds(820, 85, 120, 20);
		
		// FR speed -
		button5 = new JButton();
		button5.setText("FR speed -");
		button5.setVisible(true);
		button5.setFocusable(false);
		button5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(dp.drivingVehicle() && clk.clk_on()){
					dp.vehicle.wFR.setSpeed(dp.vehicle.wFR.speed() - 1);
					System.out.println("v0 wFR speed: " + dp.vehicle.wFR.speed());
					
					label1.setText("wFL speed: " + dp.vehicle.wFL.speed()); 
								label2.setText("wFR speed: " + dp.vehicle.wFR.speed());
								label3.setText("wBL speed: " + dp.vehicle.wBL.speed()); 
								label4.setText("wBR speed: " + dp.vehicle.wBR.speed());
								label5.setText("Vehicle speed: " + (dp.vehicle.wFR.speed() + dp.vehicle.wFL.speed())/2.0);
				}
			}
		});
		add(button5);
		button5.setBounds(820, 110, 120, 20);
		
		// Demo button
		button6 = new JButton();
		button6.setText("Car Stripper");
		button6.setVisible(true);
		button6.setFocusable(false);
		button6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				/*turn off bluecar*/
				dp.drawCarController();
				if(dp.drawCar()){
					button6.setText("Car Stripper");
				}
				else{
					button6.setText("Car Stripped");
				}
			}
		}); 
		add(button6);
		button6.setBounds(960, 110, 120, 20);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		/*Drawing boundary and others?*/
		g.drawPolygon(xpoints_panel, ypoints_panel, num_points_panel);
		g.drawPolygon(xpoints_panel_btns, ypoints_panel_btns, num_points_panel_btns);
		
		tp.draw(g);
		dp.draw(g);
		
		/*Clock*/
		g.drawPolygon(xpoints_panel_clk, ypoints_panel_clk, num_points_panel_clk);
		g.setFont(new Font("TimesRoman", Font.PLAIN, 18)); 

		g.drawString(clk.time(), 1030, 166);
	}
}
