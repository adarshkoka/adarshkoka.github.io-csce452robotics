import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

import java.lang.Math.*;

public class TrackPanel { 
    private int x;    // x-coordinate
    private int y;    // y-coordinate
	private Image trackImage;	// Light Source
	private int imgW; // Width of img
	private int imgH; // Height of img
	private double x_pos, y_pos; // position of the vehicle relative to the map and it's starting point
	Vehicle vehicle;
	
	//CSL
	private double drv_x_pos, drv_y_pos; // position used for subimage in drive panel
		
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	
	private ArrayList drivePoints;
	private boolean painting = false;
	private boolean replaying = false;
	private int rad = 7;
	
    // point initialized from parameters
    public TrackPanel(int x, int y, Vehicle v) {
		this.x = x;
		this.y = y;
		this.imgW = 750;
		this.imgH = 453;
		this.vehicle = v;
		this.x_pos = 400; //starting point
		this.y_pos = 135;
		// CSL
		this.drv_x_pos = 400;
		this.drv_y_pos = 100;
		// ^ CSL
		this.drivePoints = new ArrayList(0);
		drivePoints.add(new Point((int)x_pos, (int)y_pos, Color.BLUE, vehicle.theta(), vehicle.wFR.alpha(), vehicle.wFL.alpha(), vehicle.wFR.speed()));
					
		try{
			this.trackImage = ImageIO.read(new File("CharlotteMotorSpeedWay.jpg")); // Change this to users dir
			this.trackImage = trackImage.getScaledInstance(this.imgW, this.imgH, Image.SCALE_DEFAULT);
		} catch (Throwable IOException){
			System.out.println("The image file isn't there!\n");
		}
    }
	
	//mutator methods
	public void setX(int x){ this.x = x; }
	public void setY(int y){ this.y = y; }
	public void isReplaying(boolean replaying){ this.replaying = replaying; }
	
    // accessor methods
    public int x() { return x; }
    public int y() { return y; }
	//CSL
    public int drv_x_pos() { return (int)drv_x_pos; }
    public int drv_y_pos() { return (int)drv_y_pos; }
    //^CSL
	public Image img() { return trackImage; }
	public int imgW() { return imgW; }
	public int imgH() { return imgH; }
	public boolean painting() { return painting; }
	public boolean replaying() { return replaying; }
	public ArrayList drivePoints() { return drivePoints; }
	
	// class functions
	public void paintController(){
		if(painting){
			painting = false;
		}
		else{
			painting = true;
		}
	}
	
	public void update(){
		double tmp_x, tmp_y;
		tmp_x = x_pos;
		tmp_y = y_pos;
		x_pos += vehicle.wFR.speed()/100.0 * Math.cos(RADIAN_CONV*(vehicle.theta())); //divide 50.0 to scale the speed down
		y_pos -= vehicle.wFR.speed()/100.0 * Math.sin(RADIAN_CONV*(vehicle.theta()));
		//CSL
		double tmp_drv_x, tmp_drv_y;
		tmp_drv_x = drv_x_pos;
		tmp_drv_y = drv_y_pos;
		drv_x_pos += vehicle.wFR.speed()/72.5 * Math.cos(RADIAN_CONV*(vehicle.theta())); //divide 50.0 to scale the speed down
		drv_y_pos -= vehicle.wFR.speed()/67.5 * Math.sin(RADIAN_CONV*(vehicle.theta()));
		
		if(x_pos > x && x_pos < x+imgW && y_pos > y && y_pos < y+imgH){ //Bounds checking for trackPanel
			drivePoints.add(new Point((int)x_pos, (int)y_pos, Color.BLUE, vehicle.theta(), vehicle.wFR.alpha(), vehicle.wFL.alpha(), vehicle.wFR.speed()));
		}
		else{ //keep the car in the same position if it's at the edge
			x_pos = tmp_x;
			y_pos = tmp_y;
			drivePoints.add(new Point((int)x_pos, (int)y_pos, Color.BLUE, vehicle.theta(), vehicle.wFR.alpha(), vehicle.wFL.alpha(), vehicle.wFR.speed()));
		}
		//System.out.println(clk.count());
	}
	
	public void draw(Graphics g){
		g.drawImage(trackImage, x, y, null);

		if(painting){
			for(int i = 0; i < drivePoints.size(); i++){
				g.setColor(((Point) drivePoints.get(i)).color());
				if(replaying){
					g.setColor(Color.WHITE);
				}
				g.fillOval(((Point) drivePoints.get(i)).x()- rad/2, ((Point) drivePoints.get(i)).y() - rad/2, rad, rad);
			}
			//Drawing orientation triangle
			if(vehicle.wFR.speed() >= 0){
				int xpoints[] = {(int)(x_pos+7.0*Math.sin(RADIAN_CONV*vehicle.theta())), (int)(x_pos-7.0*Math.sin(RADIAN_CONV*vehicle.theta())), (int)(x_pos+10.0*Math.cos(RADIAN_CONV*vehicle.theta()))};
				int ypoints[] = {(int)(y_pos+7.0*Math.cos(RADIAN_CONV*vehicle.theta())), (int)(y_pos-7.0*Math.cos(RADIAN_CONV*vehicle.theta())), (int)(y_pos-10.0*Math.sin(RADIAN_CONV*vehicle.theta()))};
				g.fillPolygon(xpoints, ypoints, 3);
			}
			else{	
				int xpoints[] = {(int)(x_pos+7.0*Math.sin(RADIAN_CONV*vehicle.theta())), (int)(x_pos-7.0*Math.sin(RADIAN_CONV*vehicle.theta())), (int)(x_pos-10.0*Math.cos(RADIAN_CONV*vehicle.theta()))};
				int ypoints[] = {(int)(y_pos+7.0*Math.cos(RADIAN_CONV*vehicle.theta())), (int)(y_pos-7.0*Math.cos(RADIAN_CONV*vehicle.theta())), (int)(y_pos+10.0*Math.sin(RADIAN_CONV*vehicle.theta()))};
				g.fillPolygon(xpoints, ypoints, 3);
			}
			g.setColor(Color.BLACK);
		}
	}
}
