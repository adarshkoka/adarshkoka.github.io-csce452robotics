import java.awt.*;
import javax.swing.*;
import java.awt.image.*;

import java.lang.Math.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class Vehicle { 
    private double x;    // x-coordinate origin
    private double y;    // y-coordinate origin
	private double theta; // angle of vehicle
	
	private static final double RADIAN_CONV = (Math.PI / 180.0);
	
	/*Porsche body measurements*/
	double g = 48.25; // 2g = 96.5 in (actually g = 96.5 in, but for ours g is half)
	double d = 30.0; // 2d = 60.0 in 

	//xmid 0 = mid point top half, xmid 1 = mid point bot half, xcorner 0 = topleft, xcorner 1 = bottomleft, xcorner 2 = bottomright, xcorner 3 = topright
	private int xmid0, xmid1, xcorner0, xcorner1, xcorner2, xcorner3;
	//ymid 0 = mid point top half, ymid 1 = mid point bot half, ycorner 0 = topleft, ycorner 1 = bottomleft, ycorner 2 = bottomright, ycorner 3 = topright	
	private int ymid0, ymid1, ycorner0, ycorner1, ycorner2, ycorner3;

	FrontWheel wFL, wFR; //Left wheel is wBL, right wheel is wBR
	BackWheel wBL, wBR; //Left wheel is wBL, right wheel is wBR

    // point initialized from parameters
    public Vehicle(double xorg, double yorg) {
		this.theta = 180.0;
		this.x = xorg;
		this.y = yorg;
	
		double line_point0_x = xorg + g*Math.cos(RADIAN_CONV*theta);
		double line_point0_y = yorg - g*Math.sin(RADIAN_CONV*theta);
		
		double line_point1_x = xorg - g*Math.cos(RADIAN_CONV*theta);
		double line_point1_y = yorg + g*Math.sin(RADIAN_CONV*theta);
		
		//Corners based on the top line segment point
		xcorner0 = (int)(line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner0 = (int)(line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner3 = (int)(line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner3 = (int)(line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		//Corners based on the bottom line segment point
		xcorner1 = (int)(line_point1_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner1 = (int)(line_point1_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner2 = (int)(line_point1_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner2 = (int)(line_point1_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		//Mid points are int of line points
		xmid0 = (int) line_point0_x;
		ymid0 = (int) line_point0_y;
		
		xmid1 = (int) line_point1_x;
		ymid1 = (int) line_point1_y;
		
		this.addFrontWheels();
		this.addBackWheels();
    }
	
	//mutator methods
	public void setX(double x){ this.x = x; }
	public void setY(double y){ this.y = y; }
	public void setTheta(double theta) { this.theta = theta; } //try not to use setTheta anymore. Drive is based entirely on ackerman steering and wheel angle
	
    // accessor methods
    public double x() { return x; }
    public double y() { return y; }
	public double theta() { return theta; }
	
	public void addFrontWheels(){
		wFL = new FrontWheel(xcorner0, ycorner0, true); // left
		wFR = new FrontWheel(xcorner3, ycorner3, false); // right
	}
	
	public void addBackWheels(){
		wBL = new BackWheel(xcorner1, ycorner1, true); // left
		wBR = new BackWheel(xcorner2, ycorner2, false); // right
	}
	
	public void updateBodyAngle(){
		double omega = wFR.speed() * Math.sin(RADIAN_CONV*wFR.alpha()) / (2.*g);
		
		//System.out.println("omega: " + omega);
		theta = theta + omega;
	}
	
	/*Update vehicle position/orientation? AND all of its components*/
	public void updateBody() {	
		updateBodyAngle();
	
		double line_point0_x = x + g*Math.cos(RADIAN_CONV*theta);
		double line_point0_y = y - g*Math.sin(RADIAN_CONV*theta);
		
		double line_point1_x = x - g*Math.cos(RADIAN_CONV*theta);
		double line_point1_y = y + g*Math.sin(RADIAN_CONV*theta);
		
		//Corners based on the top line segment point
		xcorner0 = (int)(line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner0 = (int)(line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner3 = (int)(line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner3 = (int)(line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		//Corners based on the bottom line segment point
		xcorner1 = (int)(line_point1_x - d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner1 = (int)(line_point1_y + d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		xcorner2 = (int)(line_point1_x + d*Math.cos(RADIAN_CONV*(theta-90.0)));
		ycorner2 = (int)(line_point1_y - d*Math.sin(RADIAN_CONV*(theta-90.0)));
		
		//Mid points are int of line points
		xmid0 = (int) line_point0_x;
		ymid0 = (int) line_point0_y;
		
		xmid1 = (int) line_point1_x;
		ymid1 = (int) line_point1_y;
	
		//Setting the alpha of the Front Left wheel after obtaining the Front Right wheel alpha
		double r = ((2.0*g)/Math.tan(RADIAN_CONV*this.wFR.alpha())) + d;
		double alphaL = Math.atan2((2.0*g),(r+d))/RADIAN_CONV; //2*g because our g is only half
		if(alphaL >= 135.0){ //Could be the tan function, but when it goes to 0.0, instead of -1.0 it jumpts to 180.0; 135.0 was the min number and was locked due to drive angle. 
			alphaL = alphaL - 180.0; // -180.0 compensates for the jump to 180 and fixes steering. Kind of hacky, but works
		}
		
		//System.out.println(alphaL);
		//this.wFL.setAlpha(this.wFR.alpha() + 1); // Ghetto Ackerman
		this.wFL.setAlpha(alphaL);
		
		/*Update FrontWheel Parameters*/
		this.wFL.setX(line_point0_x - d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner0
		this.wFL.setY(line_point0_y + d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner0
		this.wFL.setTheta(theta);
		
		this.wFR.setX(line_point0_x + d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner3
		this.wFR.setY(line_point0_y - d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner3
		this.wFR.setTheta(theta);
		
		this.wFL.updateBody();
		this.wFR.updateBody();
		
		/*Update BackWheel Parameters*/
		this.wBL.setX(line_point1_x - d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner1
		this.wBL.setY(line_point1_y + d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner1
		this.wBL.setTheta(theta);
		
		this.wBR.setX(line_point1_x + d*Math.cos(RADIAN_CONV*(theta-90.0))); //xcorner2
		this.wBR.setY(line_point1_y - d*Math.sin(RADIAN_CONV*(theta-90.0))); //ycorner2
		this.wBR.setTheta(theta);
		
		this.wBL.updateBody();
		this.wBR.updateBody();	
	}
	
	/*Draw vehicle AND all of its components*/
	public void draw(Graphics g) {
		/*Making porsche body frame*/
		g.drawLine(xcorner0, ycorner0, xcorner3, ycorner3);
		g.drawLine(xcorner1, ycorner1, xcorner2, ycorner2);
		g.drawLine(xmid0, ymid0, xmid1, ymid1);

		this.wFL.draw(g);
		this.wFR.draw(g);
		this.wBL.draw(g);
		this.wBR.draw(g);
	}
}
